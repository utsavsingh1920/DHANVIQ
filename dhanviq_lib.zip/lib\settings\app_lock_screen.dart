import 'package:flutter/material.dart';

import 'settings_ui.dart';

class AppLockScreen extends StatelessWidget {
  const AppLockScreen({super.key});
  @override
  Widget build(BuildContext c) => SPage(
    title: 'App Lock',
    subtitle: 'Protect your financial information.',
    children: [
      SCard(
        child: Column(
          children: [
            const Icon(Icons.shield_outlined, size: 54, color: UI.purple),
            const SizedBox(height: 12),
            Text(
              'App Lock is not enabled',
              style: TextStyle(
                color: UI.ink(c),
                fontSize: 17,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'A secure lock needs PIN or biometric verification when opening and resuming the app. This screen does not activate a lock until that verification flow is implemented.',
              textAlign: TextAlign.center,
              style: TextStyle(color: UI.sub(c), height: 1.5),
            ),
          ],
        ),
      ),
    ],
  );
}
