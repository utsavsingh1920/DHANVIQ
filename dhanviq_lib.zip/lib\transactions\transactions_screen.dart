import 'package:flutter/material.dart';

import '../models/transaction_model.dart';
import '../services/transaction_service.dart';
import '../navigation/main_navigation_screen.dart';

const _navy = Color(0xFF071536);
const _purple = Color(0xFF6C3BFF);
const _muted = Color(0xFF7D879D);
const _green = Color(0xFF10B981);
const _red = Color(0xFFF0445D);
const _page = Color(0xFFF7F8FD);

String _money(double value) {
  final parts = value.toStringAsFixed(value % 1 == 0 ? 0 : 2).split('.');
  final raw = parts.first;
  final negative = raw.startsWith('-');
  final whole = negative ? raw.substring(1) : raw;
  if (whole.length <= 3) {
    return parts.join('.');
  }
  var head = whole.substring(0, whole.length - 3);
  final groups = <String>[];
  while (head.length > 2) {
    groups.insert(0, head.substring(head.length - 2));
    head = head.substring(0, head.length - 2);
  }
  if (head.isNotEmpty) {
    groups.insert(0, head);
  }
  return '${negative ? '-' : ''}${groups.join(',')},${whole.substring(whole.length - 3)}${parts.length > 1 ? '.${parts[1]}' : ''}';
}

String _date(DateTime d) => '${d.day}/${d.month}/${d.year}';
String _dateHeading(DateTime d) {
  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(d.year, d.month, d.day);

  if (day == today) {
    return 'Today, ${_date(d)}';
  }

  if (day == today.subtract(const Duration(days: 1))) {
    return 'Yesterday, ${_date(d)}';
  }

  return _date(d);
}

IconData _categoryIcon(String value) => switch (value.toLowerCase()) {
  'food' => Icons.restaurant_rounded,
  'shopping' => Icons.shopping_bag_rounded,
  'transport' => Icons.directions_car_rounded,
  'bills' => Icons.receipt_long_rounded,
  'salary' => Icons.account_balance_wallet_rounded,
  'freelance' => Icons.work_rounded,
  'entertainment' => Icons.sports_esports_rounded,
  'health' => Icons.favorite_rounded,
  'travel' => Icons.flight_rounded,
  'education' => Icons.menu_book_rounded,
  _ => Icons.account_balance_wallet_outlined,
};
Color _categoryColor(TransactionModel item) =>
    item.type == TransactionType.income
    ? _green
    : switch (item.category.toLowerCase()) {
        'food' => const Color(0xFFFF5C7A),
        'shopping' => const Color(0xFF7547F5),
        'transport' => const Color(0xFF2670D9),
        'bills' => const Color(0xFFF59E0B),
        _ => _red,
      };

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({super.key, this.onAdd});
  final VoidCallback? onAdd;
  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final _service = TransactionService.instance;
  final _searchController = TextEditingController();
  String _type = 'All';
  String _category = 'All';
  String _query = '';
  String _range = 'All Dates';
  String _sort = 'Date (Newest First)';
  DateTimeRange? _customRange;

  @override
  void initState() {
    super.initState();
    _service.addListener(_refresh);
    _service.initialize().then((_) { if (mounted) { setState(() {}); } });
  }

  void _refresh() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _service.removeListener(_refresh);
    _searchController.dispose();
    super.dispose();
  }

  List<TransactionModel> get _visible => _service.transactions.where((item) {
    final type =
        _type == 'All' ||
        (_type == 'Income' && item.type == TransactionType.income) ||
        (_type == 'Expense' && item.type == TransactionType.expense);
    final category =
        _category == 'All' ||
        item.category.toLowerCase() == _category.toLowerCase();
    final query = _query.trim().toLowerCase();
    final search =
        query.isEmpty ||
        [
          item.title,
          item.category,
          item.note,
          item.paymentMethod,
        ].any((value) => value.toLowerCase().contains(query));
    final now = DateTime.now();
    final start = switch (_range) {
      'This Week' => DateTime(now.year, now.month, now.day).subtract(Duration(days: now.weekday - 1)),
      'This Month' => DateTime(now.year, now.month),
      'Last 3 Months' => DateTime(now.year, now.month - 2),
      _ => DateTime(1900),
    };
    final inRange = _range == 'Custom Range' && _customRange != null
        ? !item.date.isBefore(_customRange!.start) &&
            item.date.isBefore(_customRange!.end.add(const Duration(days: 1)))
        : !item.date.isBefore(start);
    return type && category && search && inRange;
  }).toList()..sort((a, b) => switch (_sort) {
      'Date (Oldest First)' => a.date.compareTo(b.date),
      'Amount (High to Low)' => b.amount.compareTo(a.amount),
      'Amount (Low to High)' => a.amount.compareTo(b.amount),
      'A to Z' => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
      'Z to A' => b.title.toLowerCase().compareTo(a.title.toLowerCase()),
      _ => b.date.compareTo(a.date),
    });

  @override
  Widget build(BuildContext context) {
    final items = _visible;
    final hasTransactions = _service.transactions.isNotEmpty;
    return Scaffold(
      backgroundColor: _page,
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            SliverPersistentHeader(
              pinned: true,
              delegate: _TransactionsStickyHeader(
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Transactions',
                        style: TextStyle(
                          color: _navy,
                          fontSize: 25,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    _headerButton(Icons.sort_rounded, _openSort),
                    const SizedBox(width: 8),
                    _headerButton(Icons.tune_rounded, _openFilters),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Column(
                  children: [
                    TextField(
                      controller: _searchController,
                      onChanged: (value) => setState(() => _query = value),
                      decoration: InputDecoration(
                        hintText: 'Search transactions, category, merchant...',
                        hintStyle: const TextStyle(color: _muted, fontSize: 12),
                        prefixIcon: const Icon(
                          Icons.search_rounded,
                          color: _muted,
                        ),
                        suffixIcon: _query.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() => _query = '');
                                },
                                icon: const Icon(Icons.close_rounded),
                              ),
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: ['All', 'Income', 'Expense']
                          .map(
                            (value) => Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(right: 7),
                                child: _chip(
                                  value,
                                  _type == value,
                                  () => setState(() => _type = value),
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ],
                ),
              ),
            ),
            if (hasTransactions) SliverToBoxAdapter(child: _summary()),
            if (hasTransactions && items.isNotEmpty)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 2),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text('Transaction History',
                          style: TextStyle(color: _navy, fontSize: 16, fontWeight: FontWeight.w800)),
                      ),
                      Text('${items.length} ${items.length == 1 ? 'transaction' : 'transactions'}',
                        style: const TextStyle(color: _muted, fontSize: 11, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            if (items.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 22, 20, 110),
                  child: Center(
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(22, 30, 22, 28),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: const Color(0xFFECEEF6)),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 78,
                            height: 78,
                            decoration: const BoxDecoration(
                              color: Color(0xFFF0EDFF), shape: BoxShape.circle),
                            child: const Icon(Icons.receipt_long_rounded,
                              color: _purple, size: 36),
                          ),
                          const SizedBox(height: 18),
                          Text(
                            hasTransactions ? 'No transactions found' : 'No transactions yet',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: _navy, fontSize: 18,
                              fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            hasTransactions
                              ? 'Try another search, date range or filter to find your transactions.'
                              : 'Your income and expenses will appear here. Add your first transaction to get started.',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: _muted, fontSize: 12.5,
                              height: 1.5),
                          ),
                          const SizedBox(height: 22),
                          if (!hasTransactions)
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton.icon(
                                onPressed: _addTransaction,
                                icon: const Icon(Icons.add_rounded),
                                label: const Text('Add Your First Transaction'),
                                style: FilledButton.styleFrom(
                                  backgroundColor: _purple,
                                  minimumSize: const Size.fromHeight(52),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14)),
                                ),
                              ),
                            )
                          else
                            SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                onPressed: _clearFilters,
                                icon: const Icon(Icons.refresh_rounded),
                                label: const Text('Clear Filters'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: _purple,
                                  minimumSize: const Size.fromHeight(48),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14)),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 120),
                sliver: SliverList.builder(
                  itemCount: items.length,
                  itemBuilder: (context, index) {
                    final item = items[index];
                    final date = _dateHeading(item.date);
                    final showDate =
                        index == 0 ||
                        _date(items[index - 1].date) != _date(item.date);
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (showDate)
                          Padding(
                            padding: const EdgeInsets.fromLTRB(2, 15, 2, 7),
                            child: Text(
                              date,
                              style: const TextStyle(
                                color: _navy,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        _transactionTile(item),
                      ],
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _addTransaction() {
    if (widget.onAdd != null) {
      widget.onAdd!();
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => const AddTransactionForm(isIncome: false),
    ));
  }

  void _clearFilters() {
    _searchController.clear();
    setState(() {
      _query = '';
      _type = 'All';
      _category = 'All';
      _range = 'All Dates';
      _customRange = null;
    });
  }

  Widget _headerButton(IconData icon, VoidCallback onTap) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(12),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: SizedBox(
        width: 38,
        height: 38,
        child: Icon(icon, color: _navy, size: 20),
      ),
    ),
  );
  Widget _chip(String title, bool selected, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(11),
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      height: 38,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: selected ? _purple : Colors.white,
        borderRadius: BorderRadius.circular(11),
      ),
      child: Text(
        title,
        style: TextStyle(
          color: selected ? Colors.white : _navy,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    ),
  );
  Widget _summary() {
    final now = DateTime.now();
    final income = _service.incomeForMonth(now.year, now.month);
    final expense = _service.expensesForMonth(now.year, now.month);
    final end = DateTime(now.year, now.month + 1, 0).day;
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 18, 18, 8),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D071536),
            blurRadius: 16,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'This Month',
            style: TextStyle(color: _navy, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 3),
          Text(
            '1–$end ${_month(now.month)} ${now.year}',
            style: const TextStyle(color: _muted, fontSize: 11),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _summaryValue('₹${_money(income)}', 'Income', _green),
              _divider(),
              _summaryValue('₹${_money(expense)}', 'Expense', _red),
              _divider(),
              _summaryValue(
                '₹${_money(income - expense)}',
                'Net Balance',
                const Color(0xFF2670D9),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _month(int month) => const [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ][month - 1];
  Widget _summaryValue(String amount, String label, Color color) => Expanded(
    child: Column(
      children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            amount,
            style: TextStyle(
              color: color,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: _muted, fontSize: 9)),
      ],
    ),
  );
  Widget _divider() =>
      Container(width: 1, height: 29, color: const Color(0xFFE8EBF3));
  Widget _transactionTile(TransactionModel item) {
    final income = item.type == TransactionType.income;
    final color = _categoryColor(item);
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => _TransactionDetailsScreen(id: item.id),
            ),
          ),
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFF0F1F7)),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 22,
                  backgroundColor: color.withAlpha(24),
                  child: Icon(_categoryIcon(item.category), color: color, size: 21),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _navy, fontSize: 13,
                          fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${item.category} · ${_date(item.date)}',
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _muted, fontSize: 10.5)),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text('${income ? '+' : '-'} ₹${_money(item.amount)}',
                  style: TextStyle(color: income ? _green : _red,
                    fontSize: 12.5, fontWeight: FontWeight.w900)),
                const SizedBox(width: 2),
                const Icon(Icons.chevron_right_rounded, color: _muted, size: 17),
              ],
            ),
          ),
        ),
      ),
    );
  }


  Future<void> _openSort() async {
    final options = ['Date (Newest First)', 'Date (Oldest First)',
      'Amount (High to Low)', 'Amount (Low to High)', 'A to Z', 'Z to A'];
    final result = await showModalBottomSheet<String>(context: context,
      builder: (sheetContext) => SafeArea(child: ListView(shrinkWrap: true,
        padding: const EdgeInsets.all(18), children: [
          const Text('Sort By', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          for (final option in options) ListTile(
            title: Text(option),
            trailing: Icon(
              option == _sort ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded,
              color: option == _sort ? _purple : _muted,
            ),
            onTap: () => Navigator.pop(sheetContext, option),
          ),
        ])));
    if (mounted && result != null) {
      setState(() => _sort = result);
    }
  }

  Future<void> _openFilters() async {
    final categories = <String>['All', 'Food', 'Shopping', 'Transport', 'Bills', 'Salary', 'Freelance', 'Entertainment', 'Health', 'Travel', 'Education', 'Other'];
    String type = _type;
    String category = _category;
    String range = _range;
    DateTimeRange? customRange = _customRange;
    final result = await showModalBottomSheet<(String, String, String, DateTimeRange?)>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, update) => Container(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 26),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: SafeArea(
            top: false,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Filter Transactions',
                          style: TextStyle(
                            color: _navy,
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => update(() {
                          type = 'All';
                          category = 'All';
                          range = 'All Dates';
                          customRange = null;
                        }),
                        child: const Text('Reset'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text('Date Range', style: TextStyle(color: _navy, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 6, children: [
                    'All Dates', 'This Week', 'This Month', 'Last 3 Months', 'Custom Range'
                  ].map((value) => ChoiceChip(label: Text(value), selected: range == value,
                    onSelected: (_) async {
                      if (value == 'Custom Range') {
                        final picked = await showDateRangePicker(context: sheetContext,
                          firstDate: DateTime(2020), lastDate: DateTime(2100),
                          initialDateRange: customRange);
                        if (picked != null) {
                          update(() { range = value; customRange = picked; });
                        }
                      } else { update(() => range = value); }
                    })).toList()),
                  const SizedBox(height: 18),
                  const Text(
                    'Transaction Type',
                    style: TextStyle(color: _navy, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: ['All', 'Income', 'Expense']
                        .map(
                          (value) => Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(right: 6),
                              child: _chip(
                                value,
                                type == value,
                                () => update(() => type = value),
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Categories',
                    style: TextStyle(color: _navy, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: categories
                        .map(
                          (value) => ChoiceChip(
                            label: Text(value),
                            selected: category == value,
                            onSelected: (_) => update(() => category = value),
                          ),
                        )
                        .toList(),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () =>
                          Navigator.pop(sheetContext, (type, category, range, customRange)),
                      style: FilledButton.styleFrom(
                        backgroundColor: _purple,
                        minimumSize: const Size.fromHeight(50),
                      ),
                      child: const Text('Apply Filters'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    if (!mounted || result == null) {
      return;
    }
    setState(() {
      _type = result.$1;
      _category = result.$2;
      _range = result.$3;
      _customRange = result.$4;
    });
  }
}

class _TransactionDetailsScreen extends StatefulWidget {
  const _TransactionDetailsScreen({required this.id});
  final String id;
  @override
  State<_TransactionDetailsScreen> createState() =>
      _TransactionDetailsScreenState();
}

class _TransactionDetailsScreenState extends State<_TransactionDetailsScreen> {
  final _service = TransactionService.instance;
  bool _deleting = false;
  @override
  Widget build(BuildContext context) {
    final item = _service.getTransactionById(widget.id);
    if (item == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Transaction Details')),
        body: const Center(child: Text('Transaction no longer exists.')),
      );
    }
    final income = item.type == TransactionType.income;
    final color = _categoryColor(item);
    return Scaffold(
      backgroundColor: _page,
      appBar: AppBar(
        backgroundColor: _page,
        foregroundColor: _navy,
        title: const Text(
          'Transaction Details',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: [
          Center(
            child: CircleAvatar(
              radius: 36,
              backgroundColor: color.withAlpha(28),
              child: Icon(_categoryIcon(item.category), color: color, size: 34),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              item.title,
              style: const TextStyle(
                color: _navy,
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(
              '${income ? '+' : '-'} ₹${_money(item.amount)}',
              style: TextStyle(
                color: income ? _green : _red,
                fontSize: 24,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 22),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              children: [
                _detail(Icons.category_outlined, 'Category', item.category),
                _detail(Icons.calendar_month_rounded, 'Date', _date(item.date)),
                _detail(
                  Icons.credit_card_rounded,
                  'Payment Method',
                  item.paymentMethod,
                ),
                _detail(
                  Icons.description_outlined,
                  'Note',
                  item.note.isEmpty ? 'No note' : item.note,
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          OutlinedButton.icon(
            onPressed: _deleting ? null : () async {
              await Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => AddTransactionForm(isIncome: income, existing: item)));
              if (mounted) { setState(() {}); }
            },
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Edit Transaction'),
            style: OutlinedButton.styleFrom(foregroundColor: _purple,
              minimumSize: const Size.fromHeight(48)),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _deleting ? null : _delete,
            icon: _deleting
                ? const SizedBox(
                    width: 17,
                    height: 17,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.delete_outline_rounded),
            label: const Text('Delete Transaction'),
            style: OutlinedButton.styleFrom(
              foregroundColor: _red,
              side: const BorderSide(color: Color(0x66F0445D)),
              minimumSize: const Size.fromHeight(48),
            ),
          ),
        ],
      ),
    );
  }

  Widget _detail(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    child: Row(
      children: [
        Icon(icon, size: 18, color: _navy),
        const SizedBox(width: 10),
        SizedBox(
          width: 110,
          child: Text(
            label,
            style: const TextStyle(
              color: _navy,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            textAlign: TextAlign.right,
            style: const TextStyle(
              color: _navy,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    ),
  );
  Future<void> _delete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete transaction?'),
        content: const Text(
          'This transaction will be permanently removed from your local records.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: _red)),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) {
      return;
    }
    setState(() => _deleting = true);
    try {
      final deleted = await _service.deleteTransaction(widget.id);
      if (!mounted) {
        return;
      }
      if (deleted) {
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Transaction was not found.')),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not delete transaction. Please try again.'),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() => _deleting = false);
      }
    }
  }
}

class _TransactionsStickyHeader extends SliverPersistentHeaderDelegate {
  _TransactionsStickyHeader({required this.child});
  final Widget child;
  @override
  double get minExtent => 76;
  @override
  double get maxExtent => 76;
  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(
      color: _page,
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
      alignment: Alignment.center,
      child: child,
    );
  }

  @override
  bool shouldRebuild(covariant _TransactionsStickyHeader oldDelegate) => true;
}
