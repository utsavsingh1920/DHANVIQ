import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'splash/splash_screen.dart';
import 'services/transaction_service.dart';
import 'theme/theme_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load saved transactions before opening the app.
  await TransactionService.instance.initialize();

  // Load saved theme. First install defaults to Light Mode.
  await ThemeController.instance.initialize();

  runApp(const DhanviqApp());
}

class DhanviqApp extends StatelessWidget {
  const DhanviqApp({super.key});

  static const Color navy = Color(0xFF071536);
  static const Color purple = Color(0xFF6C3BFF);
  static const Color green = Color(0xFF16E0B5);

  static const Color lightBackground = Color(0xFFF7F8FD);
  static const Color darkBackground = Color(0xFF090F20);
  static const Color darkSurface = Color(0xFF141D32);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ThemeController.instance,
      builder: (context, child) {
        final selectedTheme = ThemeController.instance.themeMode;

        return MaterialApp(
          title: 'DHANVIQ',
          debugShowCheckedModeBanner: false,

          color: navy,

          // Light Mode remains the default.
          theme: ThemeData(
            useMaterial3: true,
            fontFamily: 'Roboto',
            brightness: Brightness.light,
            scaffoldBackgroundColor: lightBackground,

            colorScheme: ColorScheme.fromSeed(
              seedColor: purple,
              primary: purple,
              secondary: green,
              surface: lightBackground,
              brightness: Brightness.light,
            ),

            appBarTheme: const AppBarTheme(
              backgroundColor: lightBackground,
              foregroundColor: navy,
              elevation: 0,
            ),
          ),

          // Dark Mode.
          darkTheme: ThemeData(
            useMaterial3: true,
            fontFamily: 'Roboto',
            brightness: Brightness.dark,
            scaffoldBackgroundColor: darkBackground,

            colorScheme: ColorScheme.fromSeed(
              seedColor: purple,
              primary: const Color(0xFFAA8BFF),
              secondary: green,
              surface: darkSurface,
              brightness: Brightness.dark,
            ),

            appBarTheme: const AppBarTheme(
              backgroundColor: darkBackground,
              foregroundColor: Colors.white,
              elevation: 0,
            ),
          ),

          themeMode: selectedTheme,

          // Update system status bar and navigation bar with the theme.
          builder: (context, child) {
            final isDark =
                Theme.of(context).brightness == Brightness.dark;

            final systemBarColor = isDark ? darkBackground : navy;

            return AnnotatedRegion<SystemUiOverlayStyle>(
              value: SystemUiOverlayStyle(
                statusBarColor: systemBarColor,
                statusBarIconBrightness: Brightness.light,
                statusBarBrightness: Brightness.dark,
                systemNavigationBarColor: systemBarColor,
                systemNavigationBarIconBrightness: Brightness.light,
                systemNavigationBarDividerColor: systemBarColor,
              ),
              child: child ?? const SizedBox.shrink(),
            );
          },

          // Keep the existing splash → login → home flow.
          home: const SplashScreen(),
        );
      },
    );
  }
}