import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';

import '../welcome/welcome_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  static const Color _navy = Color(0xFF101936);
  static const Color _purple = Color(0xFF6C3BFF);
  static const Color _muted = Color(0xFF747D94);
  static const Color _background = Color(0xFFF8F9FE);

  final PageController _controller = PageController();
  int _page = 0;

  static const List<_OnboardingItem> _items = [
    _OnboardingItem(
      title: 'Take Control\nof Your Money',
      description: 'Track your income, expenses and\nspending habits easily.',
      asset: 'assets/images/onboarding_control.png',
      note: 'Track\nAnalyze\nImprove',
      noteAlignment: Alignment(-.70, .80),
      imageScale: 1.42,
      imageOffset: Offset(0, 8),
    ),
    _OnboardingItem(
      title: 'Plan Smarter\nBudgets',
      description:
          'Set monthly budgets and stay on track\nwith your financial plans.',
      asset: 'assets/images/onboarding_budget.png',
      note: 'Plan Today\nSpend Better\nLive Freely',
      noteAlignment: Alignment(.57, .81),
      imageScale: 1.38,
      imageOffset: Offset(0, 4),
    ),
    _OnboardingItem(
      title: 'Save for\nWhat Matters',
      description:
          'Create meaningful goals and turn your\ndreams into reality.',
      asset: 'assets/images/onboarding_goals.png',
      note: 'Small Steps\nBig Dreams',
      noteAlignment: Alignment(.52, .82),
      imageScale: 1.32,
      imageOffset: Offset(-5, 6),
    ),
    _OnboardingItem(
      title: 'Build a\nBrighter Future',
      description:
          'Understand your finances and make\nsmarter money decisions.',
      asset: 'assets/images/onboarding_growth.png',
      note: 'Better Money\nBrighter You',
      noteAlignment: Alignment(.63, .81),
      imageScale: 1.42,
      imageOffset: Offset(0, 5),
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openWelcome() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingCompleted', true);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (context, animation, secondaryAnimation) {
          return const WelcomeScreen();
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  void _next() {
    if (_page == _items.length - 1) {
      _openWelcome();
      return;
    }
    _controller.nextPage(
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeInOutCubic,
    );
  }

  void _back() {
    if (_page == 0) return;
    _controller.previousPage(
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeInOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: _background,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: _background,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: _background,
        body: Stack(
          children: [
            Positioned.fill(child: _PageBackground(page: _page)),
            SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 500),
                  child: Column(
                    children: [
                      _TopBar(
                        showBack: _page > 0,
                        onBack: _back,
                        onSkip: _openWelcome,
                      ),
                      Expanded(
                        child: PageView.builder(
                          controller: _controller,
                          itemCount: _items.length,
                          physics: const BouncingScrollPhysics(),
                          onPageChanged: (value) =>
                              setState(() => _page = value),
                          itemBuilder: (context, index) {
                            return _OnboardingPage(item: _items[index]);
                          },
                        ),
                      ),
                      _BottomBar(
                        currentPage: _page,
                        pageCount: _items.length,
                        onNext: _next,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingItem {
  const _OnboardingItem({
    required this.title,
    required this.description,
    required this.asset,
    required this.note,
    required this.noteAlignment,
    required this.imageScale,
    required this.imageOffset,
  });

  final String title;
  final String description;
  final String asset;
  final String note;
  final Alignment noteAlignment;
  final double imageScale;
  final Offset imageOffset;
}

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.showBack,
    required this.onBack,
    required this.onSkip,
  });

  final bool showBack;
  final VoidCallback onBack;
  final VoidCallback onSkip;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 54,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          children: [
            AnimatedOpacity(
              opacity: showBack ? 1 : 0,
              duration: const Duration(milliseconds: 200),
              child: IgnorePointer(
                ignoring: !showBack,
                child: IconButton(
                  onPressed: onBack,
                  icon: const Icon(
                    Icons.arrow_back_ios_new_rounded,
                    color: _OnboardingScreenState._navy,
                    size: 21,
                  ),
                ),
              ),
            ),
            const Spacer(),
            TextButton(
              onPressed: onSkip,
              child: const Text(
                'Skip',
                style: TextStyle(
                  color: _OnboardingScreenState._muted,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardingPage extends StatelessWidget {
  const _OnboardingPage({required this.item});

  final _OnboardingItem item;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxHeight < 600;
        return Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: compact ? 22 : 25),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: compact ? 2 : 7),
                  Text(
                    item.title,
                    style: TextStyle(
                      color: _OnboardingScreenState._navy,
                      fontSize: compact ? 28 : 32,
                      height: 1.10,
                      letterSpacing: -0.7,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: compact ? 8 : 11),
                  Text(
                    item.description,
                    style: TextStyle(
                      color: _OnboardingScreenState._muted,
                      fontSize: compact ? 13 : 14,
                      height: 1.45,
                    ),
                  ),
                  SizedBox(height: compact ? 0 : 2),
                  Expanded(
                    child: ClipRect(
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Positioned.fill(
                            left: 0,
                            right: 0,
                            child: Transform.translate(
                              offset: item.imageOffset,
                              child: Transform.scale(
                                scale: item.imageScale,
                                child: Image.asset(
                                  item.asset,
                                  fit: BoxFit.contain,
                                  alignment: const Alignment(0, -.08),
                                  filterQuality: FilterQuality.high,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: item.noteAlignment,
                            child: Transform.rotate(
                              angle: -.11,
                              child: Text(
                                item.note,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: const Color(0xFF6753B5),
                                  fontFamily: 'cursive',
                                  fontSize: compact ? 11.5 : 12.5,
                                  height: 1.0,
                                  fontStyle: FontStyle.italic,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _PageBackground extends StatelessWidget {
  const _PageBackground({required this.page});

  final int page;

  @override
  Widget build(BuildContext context) {
    const purple = Color(0xFF7950F2);
    const mint = Color(0xFF22D3B6);
    final topColor = page == 1 || page == 3 ? mint : purple;
    final middleColor = page == 0 || page == 2 ? mint : purple;
    final bottomColor = page == 3 ? mint : purple;

    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFBFBFF), Color(0xFFF7F8FF), Color(0xFFF4FAFC)],
            ),
          ),
        ),
        Positioned(
          top: -170,
          left: -130,
          child: Transform.rotate(
            angle: -.35,
            child: Container(
              width: 360,
              height: 300,
              decoration: BoxDecoration(
                color: topColor.withValues(alpha: .16),
                borderRadius: BorderRadius.circular(145),
              ),
            ),
          ),
        ),
        Positioned(
          top: page == 0 ? 115 : 155,
          right: -175,
          child: Container(
            width: 430,
            height: 430,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  middleColor.withValues(alpha: .20),
                  middleColor.withValues(alpha: .075),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        Positioned(
          top: 355,
          left: page.isEven ? -215 : -165,
          child: Container(
            width: 390,
            height: 390,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [topColor.withValues(alpha: .14), Colors.transparent],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -145,
          left: page.isEven ? -135 : 75,
          child: Transform.rotate(
            angle: page.isEven ? -.24 : .24,
            child: Container(
              width: 480,
              height: 290,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    bottomColor.withValues(alpha: .19),
                    mint.withValues(alpha: .11),
                  ],
                ),
                borderRadius: BorderRadius.circular(155),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _BottomBar extends StatelessWidget {
  const _BottomBar({
    required this.currentPage,
    required this.pageCount,
    required this.onNext,
  });

  final int currentPage;
  final int pageCount;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(29, 7, 24, 18),
      child: Row(
        children: [
          ...List.generate(pageCount, (index) {
            final selected = currentPage == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              width: selected ? 28 : 7,
              height: 7,
              margin: const EdgeInsets.only(right: 7),
              decoration: BoxDecoration(
                color: selected
                    ? _OnboardingScreenState._purple
                    : const Color(0xFFDDE1EE),
                borderRadius: BorderRadius.circular(20),
              ),
            );
          }),
          const Spacer(),
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(29),
              gradient: const LinearGradient(
                colors: [Color(0xFF8150FF), Color(0xFF6329EF)],
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x4D6C3BFF),
                  blurRadius: 22,
                  offset: Offset(0, 9),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onNext,
                borderRadius: BorderRadius.circular(29),
                child: const Center(
                  child: Icon(
                    Icons.arrow_forward_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
