import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'settings_ui.dart';

class HelpSupportScreen extends StatelessWidget {
  const HelpSupportScreen({super.key});
  @override
  Widget build(BuildContext c) => SPage(
    title: 'Help & Support',
    subtitle: 'Quick answers for everyday money tracking.',
    children: [
      const STitle('FREQUENTLY ASKED QUESTIONS'),
      SCard(
        child: Column(
          children: [
            for (final q in [
              (
                'How do I add a transaction?',
                'Use the + button in the bottom navigation, then choose income or expense.',
              ),
              (
                'Where can I view my spending?',
                'Open Transactions for entries and Insights for spending summaries.',
              ),
              (
                'Is this a payment app?',
                'No. DHANVIQ helps you manually track money; it does not transfer funds.',
              ),
              (
                'Where is my data stored?',
                'Your current transaction records are saved locally on this device.',
              ),
            ])
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: Text(
                  q.$1,
                  style: TextStyle(
                    color: UI.ink(c),
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                ),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Text(
                      q.$2,
                      style: TextStyle(color: UI.sub(c), height: 1.5),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
      const STitle('FEEDBACK'),
      SCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Have a suggestion?',
              style: TextStyle(color: UI.ink(c), fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 7),
            Text(
              'You can copy a feedback template and share it through your preferred app.',
              style: TextStyle(color: UI.sub(c)),
            ),
            const SizedBox(height: 12),
            SButton('Copy Feedback Template', () async {
              await Clipboard.setData(
                const ClipboardData(
                  text: 'DHANVIQ Feedback\nFeature / Issue:\nDetails:\nDevice:',
                ),
              );
              if (c.mounted) UI.toast(c, 'Feedback template copied');
            }, icon: Icons.copy_outlined),
          ],
        ),
      ),
    ],
  );
}
