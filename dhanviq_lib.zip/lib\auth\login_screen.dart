import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../navigation/main_navigation_screen.dart';

import 'signup_screen.dart';

const _navy = Color(0xFF101936);
const _purple = Color(0xFF6C3BFF);
const _muted = Color(0xFF747D94);
const _background = Color(0xFFF8F9FE);

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _hidePassword = true;
  bool _rememberMe = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _openSignUp() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => const SignUpScreen()),
    );
  }

  Future<void> _login() async {
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;
    // DEMO ONLY: form validation, not credential authentication.
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingCompleted', true);
    await prefs.setBool('isLoggedIn', true);
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const MainNavigationScreen()),
      (route) => false,
    );
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: _background,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: _background,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: _background,
        body: Stack(
          children: [
            const Positioned.fill(child: _Background()),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: constraints.maxWidth,
                        height: 760,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(25, 6, 25, 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _topBar(),
                              Expanded(
                                child: Form(
                                  key: _formKey,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const _Brand(),
                                      const SizedBox(height: 12),
                                      const Text(
                                        'Welcome Back',
                                        style: TextStyle(
                                          color: _navy,
                                          fontSize: 26,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: -.5,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      const Text(
                                        'Sign in to continue your financial journey.',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: _muted,
                                          fontSize: 13,
                                        ),
                                      ),
                                      const SizedBox(height: 17),
                                      _field(
                                        controller: _emailController,
                                        label: 'Email Address',
                                        hint: 'you@example.com',
                                        icon: Icons.mail_outline_rounded,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        validator: (value) {
                                          final email = value?.trim() ?? '';
                                          return email.isEmpty ||
                                                  !email.contains('@')
                                              ? 'Enter a valid email address'
                                              : null;
                                        },
                                      ),
                                      const SizedBox(height: 9),
                                      _field(
                                        controller: _passwordController,
                                        label: 'Password',
                                        hint: 'Enter your password',
                                        icon: Icons.lock_outline_rounded,
                                        obscureText: _hidePassword,
                                        suffix: IconButton(
                                          onPressed: () => setState(
                                            () =>
                                                _hidePassword = !_hidePassword,
                                          ),
                                          icon: Icon(
                                            _hidePassword
                                                ? Icons.visibility_outlined
                                                : Icons.visibility_off_outlined,
                                            color: _muted,
                                          ),
                                        ),
                                        validator: (value) =>
                                            (value ?? '').length < 6
                                            ? 'Minimum 6 characters required'
                                            : null,
                                      ),
                                      const SizedBox(height: 9),
                                      Row(
                                        children: [
                                          _checkBox(
                                            _rememberMe,
                                            () => setState(
                                              () => _rememberMe = !_rememberMe,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          const Text(
                                            'Remember me',
                                            style: TextStyle(
                                              color: _muted,
                                              fontSize: 12.5,
                                            ),
                                          ),
                                          const Spacer(),
                                          TextButton(
                                            onPressed: () =>
                                                _message('Forgot Password'),
                                            style: TextButton.styleFrom(
                                              foregroundColor: _purple,
                                              padding: EdgeInsets.zero,
                                              minimumSize: const Size(0, 32),
                                              tapTargetSize:
                                                  MaterialTapTargetSize
                                                      .shrinkWrap,
                                            ),
                                            child: const Text(
                                              'Forgot Password?',
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.w600,
                                                decoration:
                                                    TextDecoration.underline,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),
                                      _primaryButton('Login', _login),
                                      const SizedBox(height: 13),
                                      _divider('or continue with'),
                                      const SizedBox(height: 10),
                                      _socialRow(),
                                      const SizedBox(height: 14),
                                      _infoCard(),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topBar() {
    return SizedBox(
      height: 44,
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.maybePop(context),
            padding: EdgeInsets.zero,
            alignment: Alignment.centerLeft,
            icon: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: _navy,
              size: 21,
            ),
          ),
          const Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                "Don't have an account?",
                style: TextStyle(color: _muted, fontSize: 11.5),
              ),
              GestureDetector(
                onTap: _openSignUp,
                child: const Text(
                  'Sign Up',
                  style: TextStyle(
                    color: _purple,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    bool obscureText = false,
    Widget? suffix,
    String? Function(String?)? validator,
  }) {
    return Container(
      height: 58,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .94),
        borderRadius: BorderRadius.circular(17),
        boxShadow: const [
          BoxShadow(
            color: Color(0x126C3BFF),
            blurRadius: 16,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        obscureText: obscureText,
        validator: validator,
        style: const TextStyle(
          color: _navy,
          fontSize: 13.5,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: const Color(0xFF5E6987), size: 23),
          suffixIcon: suffix,
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
            color: Color(0xFF43506F),
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          hintStyle: const TextStyle(color: _muted, fontSize: 12.5),
          errorStyle: const TextStyle(fontSize: 0, height: 0),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 9),
        ),
      ),
    );
  }

  Widget _checkBox(bool value, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 22,
        height: 22,
        decoration: BoxDecoration(
          color: value ? _purple : Colors.white,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: value ? _purple : const Color(0xFFC8CDDA)),
        ),
        child: value
            ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
            : null,
      ),
    );
  }

  Widget _primaryButton(String label, VoidCallback onTap) {
    return Container(
      width: double.infinity,
      height: 51,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF8150FF), Color(0xFF6329EF)],
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3D6C3BFF),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Row(
            children: [
              const SizedBox(width: 42),
              Expanded(
                child: Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(right: 18),
                child: Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _divider(String text) {
    return Row(
      children: [
        const Expanded(child: Divider(color: Color(0xFFCFD4E2))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            text,
            style: const TextStyle(color: _muted, fontSize: 11.5),
          ),
        ),
        const Expanded(child: Divider(color: Color(0xFFCFD4E2))),
      ],
    );
  }

  Widget _socialRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _socialButton(
          const Text(
            'G',
            style: TextStyle(
              color: Color(0xFF4285F4),
              fontSize: 21,
              fontWeight: FontWeight.w900,
            ),
          ),
          'Google Sign In',
        ),
        const SizedBox(width: 20),
        _socialButton(
          const Icon(Icons.apple_rounded, color: _navy, size: 27),
          'Apple Sign In',
        ),
        const SizedBox(width: 20),
        _socialButton(
          const Icon(Icons.mail_rounded, color: _navy, size: 23),
          'Email Sign In',
        ),
      ],
    );
  }

  Widget _socialButton(Widget child, String message) {
    return Material(
      color: Colors.white,
      elevation: 2,
      shadowColor: const Color(0x226C3BFF),
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: () => _message(message),
        borderRadius: BorderRadius.circular(17),
        child: SizedBox(width: 52, height: 48, child: Center(child: child)),
      ),
    );
  }

  Widget _infoCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .72),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withValues(alpha: .8)),
      ),
      child: const Row(
        children: [
          Icon(Icons.verified_user_rounded, color: _purple, size: 26),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your data is safe with us.',
                  style: TextStyle(
                    color: _navy,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'We use industry-standard security to protect your information.',
                  style: TextStyle(color: _muted, fontSize: 10.5, height: 1.25),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Brand extends StatelessWidget {
  const _Brand();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: 80,
          height: 80,
          child: Image.asset(
            'assets/icon/dhanviq_icon.png',
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          'DHANVIQ',
          style: TextStyle(
            color: _navy,
            fontSize: 24,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.3,
          ),
        ),
        const Text(
          'Track  •  Save  •  Grow',
          style: TextStyle(color: _muted, fontSize: 10.5, letterSpacing: 1.1),
        ),
      ],
    );
  }
}

class _Background extends StatelessWidget {
  const _Background();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFBFBFF), Color(0xFFF7F9FF), Color(0xFFF4FAFC)],
            ),
          ),
        ),
        Positioned(
          top: -150,
          left: -115,
          child: _blob(310, _purple, .07, -.35),
        ),
        Positioned(
          top: 120,
          right: -170,
          child: _blob(370, const Color(0xFF19D7B0), .065, .3),
        ),
        Positioned(
          bottom: -155,
          left: -105,
          child: _blob(390, const Color(0xFF5A8DFF), .10, .45),
        ),
        Positioned(
          bottom: -135,
          right: -120,
          child: _blob(360, _purple, .09, -.4),
        ),
      ],
    );
  }

  static Widget _blob(double size, Color color, double opacity, double angle) {
    return Transform.rotate(
      angle: angle + math.pi / 18,
      child: Container(
        width: size,
        height: size * .68,
        decoration: BoxDecoration(
          color: color.withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(size * .34),
        ),
      ),
    );
  }
}
