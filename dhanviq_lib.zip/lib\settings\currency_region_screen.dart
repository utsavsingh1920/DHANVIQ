import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'settings_ui.dart';

class CurrencyRegionScreen extends StatefulWidget {
  const CurrencyRegionScreen({super.key});
  @override
  State<CurrencyRegionScreen> createState() => _CurrencyState();
}

class _CurrencyState extends State<CurrencyRegionScreen> {
  String currency = 'INR', region = 'India';
  bool ready = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        currency = p.getString('dhanviq_currency') ?? 'INR';
        region = p.getString('dhanviq_region') ?? 'India';
        ready = true;
      });
    }
  }

  Future<void> save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('dhanviq_currency', currency);
    await p.setString('dhanviq_region', region);
    if (mounted) UI.toast(context, 'Display preferences saved');
  }

  @override
  Widget build(BuildContext c) => SPage(
    title: 'Currency & Region',
    subtitle: 'These are saved preferences. Financial amounts elsewhere in the app will continue to use their existing display format until currency formatting is connected across those screens.',
    children: [
      if (!ready)
        const Center(child: CircularProgressIndicator())
      else
        SCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Currency',
                style: TextStyle(color: UI.ink(c), fontWeight: FontWeight.w700),
              ),
              DropdownButtonFormField<String>(
                initialValue: currency,
                items: const [
                  DropdownMenuItem(
                    value: 'INR',
                    child: Text('INR · Indian Rupee (₹)'),
                  ),
                ],
                onChanged: (v) => setState(() => currency = v ?? currency),
              ),
              const SizedBox(height: 16),
              Text(
                'Region',
                style: TextStyle(color: UI.ink(c), fontWeight: FontWeight.w700),
              ),
              DropdownButtonFormField<String>(
                initialValue: region,
                items: const [
                  DropdownMenuItem(value: 'India', child: Text('India')),
                ],
                onChanged: (v) => setState(() => region = v ?? region),
              ),
              const SizedBox(height: 18),
              SButton('Save Preferences', save),
            ],
          ),
        ),
    ],
  );
}
