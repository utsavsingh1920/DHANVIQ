import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/transaction_service.dart';
import 'settings_ui.dart';

class DataBackupScreen extends StatefulWidget {
  const DataBackupScreen({super.key});
  @override
  State<DataBackupScreen> createState() => _BackupState();
}

class _BackupState extends State<DataBackupScreen> {
  bool busy = false;
  Future<void> export() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await TransactionService.instance.initialize();
      final transactions = TransactionService.instance.transactions;
      final payload = jsonEncode({
        'app': 'DHANVIQ',
        'format': 'transactions-v1',
        'exportedAt': DateTime.now().toIso8601String(),
        'transactions': transactions.map((t) => t.toJson()).toList(),
      });
      await Clipboard.setData(ClipboardData(text: payload));
      if (mounted) {
        UI.toast(
          context,
          '${transactions.length} transactions copied as JSON. Paste into a secure file to keep a backup.',
        );
      }
    } catch (_) {
      if (mounted) UI.toast(context, 'Could not export transactions');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext c) => SPage(
    title: 'Data & Backup',
    subtitle: 'Keep a personal copy of your recorded transactions.',
    children: [
      SCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.cloud_download_outlined,
              size: 38,
              color: UI.purple,
            ),
            const SizedBox(height: 12),
            Text(
              'Export transactions',
              style: TextStyle(
                color: UI.ink(c),
                fontWeight: FontWeight.w800,
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 7),
            Text(
              'Copy your transactions as JSON. Paste the copied text into a secure file and save it yourself. This does not upload anything to cloud storage.',
              style: TextStyle(color: UI.sub(c), height: 1.5),
            ),
            const SizedBox(height: 18),
            SButton(
              busy ? 'Exporting...' : 'Copy Transaction Backup',
              busy ? null : export,
              icon: Icons.copy_all_outlined,
            ),
          ],
        ),
      ),
      const STitle('IMPORTANT'),
      SCard(
        child: Text(
          'This version exports transactions only. Budget, goals and profile data are not included. Import/restore is not available yet; do not delete your original app data assuming this backup can be restored here.',
          style: TextStyle(color: UI.sub(c), height: 1.5),
        ),
      ),
    ],
  );
}
