import 'package:flutter/material.dart';

import 'settings_ui.dart';

class AboutDhanviqScreen extends StatelessWidget {
  const AboutDhanviqScreen({super.key});
  @override
  Widget build(BuildContext c) => SPage(
    title: 'About DHANVIQ',
    children: [
      const SizedBox(height: 18),
      const Center(
        child: CircleAvatar(
          radius: 43,
          backgroundColor: Color(0xFFECE6FF),
          child: Icon(
            Icons.account_balance_wallet_rounded,
            color: UI.purple,
            size: 45,
          ),
        ),
      ),
      const SizedBox(height: 12),
      Center(
        child: Text(
          'DHANVIQ',
          style: TextStyle(
            color: UI.ink(c),
            fontSize: 24,
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
          ),
        ),
      ),
      const SizedBox(height: 5),
      Center(
        child: Text('Track • Plan • Grow', style: TextStyle(color: UI.sub(c))),
      ),
      const SizedBox(height: 24),
      SCard(
        child: Column(
          children: [
            SRow(
              icon: Icons.wallet_outlined,
              title: 'Personal Finance',
              subtitle: 'Record income and expenses',
              trailing: const SizedBox.shrink(),
            ),
            Divider(color: UI.border(c)),
            SRow(
              icon: Icons.pie_chart_outline,
              title: 'Budget & Insights',
              subtitle: 'Understand your spending',
              trailing: const SizedBox.shrink(),
            ),
            Divider(color: UI.border(c)),
            SRow(
              icon: Icons.flag_outlined,
              title: 'Savings Goals',
              subtitle: 'Plan your financial milestones',
              trailing: const SizedBox.shrink(),
            ),
          ],
        ),
      ),
      const SizedBox(height: 18),
      Center(
        child: Text(
          'Built for everyday money management',
          style: TextStyle(color: UI.sub(c), fontSize: 12),
        ),
      ),
    ],
  );
}
