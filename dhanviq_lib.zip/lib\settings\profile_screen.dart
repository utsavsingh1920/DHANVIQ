import 'package:flutter/material.dart';

import 'profile_service.dart';
import 'settings_ui.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileState();
}

class _ProfileState extends State<ProfileScreen> {
  final keyForm = GlobalKey<FormState>();
  final name = TextEditingController(),
      email = TextEditingController(),
      phone = TextEditingController(),
      dob = TextEditingController(),
      about = TextEditingController();
  String gender = '';
  bool saving = false, loaded = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await ProfileService.instance.load();
    if (!mounted) return;
    final p = ProfileService.instance;
    setState(() {
      name.text = p.name;
      email.text = p.email;
      phone.text = p.phone;
      dob.text = p.dob;
      about.text = p.about;
      gender = p.gender;
      loaded = true;
    });
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    phone.dispose();
    dob.dispose();
    about.dispose();
    super.dispose();
  }

  Future<void> _date() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime(2004),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (d != null && mounted) {
      setState(
        () => dob.text =
            '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}',
      );
    }
  }

  Widget field(
    String label,
    TextEditingController ctl,
    IconData icon, {
    bool required = false,
    bool mail = false,
    int lines = 1,
    bool readOnly = false,
    VoidCallback? onTap,
    TextInputType? type,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 13),
    child: TextFormField(
      controller: ctl,
      maxLines: lines,
      readOnly: readOnly,
      onTap: onTap,
      keyboardType:
          type ?? (mail ? TextInputType.emailAddress : TextInputType.text),
      validator: (v) {
        final s = (v ?? '').trim();
        if (required && s.isEmpty) return 'Enter $label';
        if (mail && !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(s)) {
          return 'Enter a valid email';
        }
        return null;
      },
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: UI.purple),
        filled: true,
        fillColor: UI.card(context),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
  );
  Future<void> save() async {
    if (!keyForm.currentState!.validate() || saving) return;
    setState(() => saving = true);
    try {
      await ProfileService.instance.save(
        newName: name.text.trim(),
        newEmail: email.text.trim(),
        newPhone: phone.text.trim(),
        newDob: dob.text,
        newGender: gender,
        newAbout: about.text.trim(),
      );
      if (mounted) UI.toast(context, 'Profile saved successfully');
    } catch (_) {
      if (mounted) UI.toast(context, 'Could not save profile');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext c) => SPage(
    title: 'My Profile',
    children: [
      if (!loaded)
        const Center(child: CircularProgressIndicator())
      else
        Form(
          key: keyForm,
          child: Column(
            children: [
              const SizedBox(height: 10),
              const CircleAvatar(
                radius: 47,
                backgroundColor: Color(0xFFECE6FF),
                child: Icon(Icons.person_rounded, color: UI.purple, size: 52),
              ),
              const SizedBox(height: 10),
              Text(
                'Personal Information',
                style: TextStyle(
                  color: UI.ink(c),
                  fontWeight: FontWeight.w800,
                  fontSize: 17,
                ),
              ),
              const SizedBox(height: 20),
              field('Full Name', name, Icons.person_outline, required: true),
              field(
                'Email Address',
                email,
                Icons.email_outlined,
                required: true,
                mail: true,
              ),
              field(
                'Mobile Number',
                phone,
                Icons.phone_outlined,
                type: TextInputType.phone,
              ),
              field(
                'Date of Birth (Optional)',
                dob,
                Icons.calendar_month_outlined,
                readOnly: true,
                onTap: _date,
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 13),
                child: DropdownButtonFormField<String>(
                  initialValue: gender.isEmpty ? null : gender,
                  decoration: InputDecoration(
                    labelText: 'Gender (Optional)',
                    filled: true,
                    fillColor: UI.card(c),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  items: const ['Male', 'Female', 'Other', 'Prefer not to say']
                      .map((v) => DropdownMenuItem(value: v, child: Text(v)))
                      .toList(),
                  onChanged: (v) => setState(() => gender = v ?? ''),
                ),
              ),
              field(
                'About Me (Optional)',
                about,
                Icons.description_outlined,
                lines: 3,
              ),
              const SizedBox(height: 8),
              SButton(
                saving ? 'Saving...' : 'Save Changes',
                saving ? null : save,
                icon: Icons.save_outlined,
              ),
            ],
          ),
        ),
    ],
  );
}
