import 'package:flutter/material.dart';

import 'settings_ui.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});
  @override
  Widget build(BuildContext c) => SPage(
    title: 'Privacy Policy',
    subtitle: 'Current on-device data information. This is not a published legal privacy policy.',
    children: [
      SCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final item in [
              (
                'Your records',
                'Transactions are stored on your device using SharedPreferences in the current app implementation.',
              ),
              (
                'Profile information',
                'The profile details you enter are stored locally on this device.',
              ),
              (
                'Data export',
                'The export feature lets you copy transaction data. Treat exported information as private.',
              ),
              (
                'Sign out',
                'Signing out changes your login state; it does not delete financial records stored on this device.',
              ),
              (
                'Before publishing',
                'Review all app features, external services and data practices, then publish an accurate privacy policy before distributing the app.',
              ),
            ]) ...[
              Text(
                item.$1,
                style: TextStyle(color: UI.ink(c), fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 5),
              Text(item.$2, style: TextStyle(color: UI.sub(c), height: 1.5)),
              const SizedBox(height: 18),
            ],
          ],
        ),
      ),
    ],
  );
}
