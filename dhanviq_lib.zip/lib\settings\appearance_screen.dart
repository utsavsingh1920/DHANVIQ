import 'package:flutter/material.dart';

import '../theme/theme_controller.dart';
import 'settings_ui.dart';

class AppearanceScreen extends StatelessWidget {
  const AppearanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SPage(
      title: 'Appearance',
      subtitle:
          'Choose how DHANVIQ looks. Your selection is saved automatically.',
      children: [
        AnimatedBuilder(
          animation: ThemeController.instance,
          builder: (context, child) {
            return SCard(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: RadioGroup<ThemeMode>(
                groupValue: ThemeController.instance.themeMode,
                onChanged: (mode) {
                  if (mode != null) {
                    ThemeController.instance.setThemeMode(mode);
                  }
                },
                child: Column(
                  children: [
                    SRow(
                      icon: Icons.light_mode_outlined,
                      title: 'Light Mode',
                      subtitle: 'Bright and clean',
                      trailing: const Radio<ThemeMode>(
                        value: ThemeMode.light,
                        activeColor: UI.purple,
                      ),
                      onTap: () {
                        ThemeController.instance.setThemeMode(ThemeMode.light);
                      },
                    ),
                    Divider(height: 1, indent: 52, color: UI.border(context)),
                    SRow(
                      icon: Icons.dark_mode_outlined,
                      title: 'Dark Mode',
                      subtitle: 'Comfortable in low light',
                      trailing: const Radio<ThemeMode>(
                        value: ThemeMode.dark,
                        activeColor: UI.purple,
                      ),
                      onTap: () {
                        ThemeController.instance.setThemeMode(ThemeMode.dark);
                      },
                    ),
                    Divider(height: 1, indent: 52, color: UI.border(context)),
                    SRow(
                      icon: Icons.settings_suggest_outlined,
                      title: 'System Default',
                      subtitle: 'Follow your phone settings',
                      trailing: const Radio<ThemeMode>(
                        value: ThemeMode.system,
                        activeColor: UI.purple,
                      ),
                      onTap: () {
                        ThemeController.instance.setThemeMode(ThemeMode.system);
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
