import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'settings_ui.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NState();
}

class _NState extends State<NotificationsScreen> {
  bool budget = true, goals = true, summary = false, ready = false;
  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        budget = p.getBool('dhanviq_notify_budget') ?? true;
        goals = p.getBool('dhanviq_notify_goals') ?? true;
        summary = p.getBool('dhanviq_notify_summary') ?? false;
        ready = true;
      });
    }
  }

  Future<void> set(String key, bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dhanviq_notify_$key', value);
    if (mounted) {
      setState(() {
        if (key == 'budget') budget = value;
        if (key == 'goals') goals = value;
        if (key == 'summary') summary = value;
      });
    }
  }

  @override
  Widget build(BuildContext c) => SPage(
    title: 'Notifications',
    subtitle: 'Save your reminder preferences. Automatic push notifications require a separate scheduling integration.',
    children: [
      if (!ready)
        const Center(child: CircularProgressIndicator())
      else
        SCard(
          child: Column(
            children: [
              SRow(
                icon: Icons.pie_chart_outline,
                title: 'Budget Alerts',
                subtitle: 'Budget reminder preference',
                trailing: Switch(
                  value: budget,
                  onChanged: (v) => set('budget', v),
                ),
              ),
              Divider(color: UI.border(c)),
              SRow(
                icon: Icons.flag_outlined,
                title: 'Goal Reminders',
                subtitle: 'Savings goal reminder preference',
                trailing: Switch(
                  value: goals,
                  onChanged: (v) => set('goals', v),
                ),
              ),
              Divider(color: UI.border(c)),
              SRow(
                icon: Icons.summarize_outlined,
                title: 'Weekly Summary',
                subtitle: 'Weekly summary preference',
                trailing: Switch(
                  value: summary,
                  onChanged: (v) => set('summary', v),
                ),
              ),
            ],
          ),
        ),
    ],
  );
}
