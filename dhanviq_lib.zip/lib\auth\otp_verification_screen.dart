import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../navigation/main_navigation_screen.dart';

const _navy = Color(0xFF101936);
const _purple = Color(0xFF6C3BFF);
const _mint = Color(0xFF19D7B0);
const _muted = Color(0xFF747D94);
const _background = Color(0xFFF8F9FE);

class OtpVerificationScreen extends StatefulWidget {
  const OtpVerificationScreen({
    super.key,
    required this.phoneNumber,
    this.destination,
  });

  final String phoneNumber;

  /// Tests या किसी alternate flow में custom destination pass कर सकते हैं।
  final Widget? destination;

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen>
    with SingleTickerProviderStateMixin {
  final List<TextEditingController> _controllers = List.generate(
    6,
    (_) => TextEditingController(),
  );
  final List<FocusNode> _focusNodes = List.generate(6, (_) => FocusNode());

  late final AnimationController _pulseController;
  Timer? _resendTimer;
  int _secondsRemaining = 30;
  bool _isVerifying = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
      lowerBound: .92,
      upperBound: 1.06,
    );
    _startResendTimer();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusNodes.first.requestFocus();
    });
  }

  @override
  void dispose() {
    _resendTimer?.cancel();
    _pulseController.dispose();
    for (final controller in _controllers) {
      controller.dispose();
    }
    for (final node in _focusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  void _startResendTimer() {
    _resendTimer?.cancel();
    setStateIfMounted(() => _secondsRemaining = 30);
    _resendTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_secondsRemaining <= 1) {
        timer.cancel();
        setState(() => _secondsRemaining = 0);
      } else {
        setState(() => _secondsRemaining--);
      }
    });
  }

  void setStateIfMounted(VoidCallback callback) {
    if (mounted) setState(callback);
  }

  String get _otp => _controllers.map((controller) => controller.text).join();

  void _onDigitChanged(int index, String value) {
    if (_isVerifying) return;

    if (value.isNotEmpty && index < _focusNodes.length - 1) {
      _focusNodes[index + 1].requestFocus();
    }

    if (value.isEmpty && index > 0) {
      _focusNodes[index - 1].requestFocus();
    }

    if (_otp.length == 6) {
      FocusScope.of(context).unfocus();
      _verifyOtp();
    }
  }

  Future<void> _verifyOtp() async {
    if (_isVerifying || _otp.length != 6) return;

    _resendTimer?.cancel();
    setState(() => _isVerifying = true);
    _pulseController.repeat(reverse: true);

    // DEMO ONLY: any six digits are accepted; no SMS is sent or verified.
    await Future<void>.delayed(const Duration(milliseconds: 1900));
    if (!mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboardingCompleted', true);
    await prefs.setBool('isLoggedIn', true);
    if (!mounted) return;

    _pulseController.stop();
    Navigator.of(context).pushAndRemoveUntil(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 420),
        pageBuilder: (_, animation, secondaryAnimation) =>
            widget.destination ?? const MainNavigationScreen(),
        transitionsBuilder: (_, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
      (route) => false,
    );
  }

  void _resendOtp() {
    if (_secondsRemaining != 0 || _isVerifying) return;
    for (final controller in _controllers) {
      controller.clear();
    }
    _focusNodes.first.requestFocus();
    _startResendTimer();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Demo mode: no SMS is sent. Enter any 6 digits.')));
  }

  String get _timerText {
    final seconds = _secondsRemaining.toString().padLeft(2, '0');
    return '00:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: _background,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: _background,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: _background,
        body: Stack(
          children: [
            const Positioned.fill(child: _OtpBackground()),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: constraints.maxWidth,
                        height: 748,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(22, 6, 22, 14),
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 380),
                            switchInCurve: Curves.easeOutCubic,
                            switchOutCurve: Curves.easeInCubic,
                            child: _isVerifying
                                ? _buildVerifyingContent()
                                : _buildOtpContent(),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOtpContent() {
    return Column(
      key: const ValueKey('otp'),
      children: [
        _topBar(),
        const _BrandHeader(),
        const SizedBox(height: 46),
        const Text(
          'Verify Your Account',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _navy,
            fontSize: 29,
            fontWeight: FontWeight.w800,
            letterSpacing: -.45,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          "Demo mode: enter any 6 digits to continue.\nPhone: ${widget.phoneNumber} (no SMS sent)",
          textAlign: TextAlign.center,
          style: const TextStyle(color: _muted, fontSize: 14.5, height: 1.45),
        ),
        const SizedBox(height: 30),
        _otpFields(),
        const SizedBox(height: 24),
        _resendRow(),
        const Spacer(),
        const _BottomInfoCard(
          icon: Icons.verified_user_rounded,
          title: 'Your data is safe with us.',
          subtitle:
              'We use industry-standard security to protect your information.',
        ),
      ],
    );
  }

  Widget _buildVerifyingContent() {
    return Column(
      key: const ValueKey('verifying'),
      children: [
        _topBar(showBack: false),
        const _BrandHeader(),
        const SizedBox(height: 34),
        ScaleTransition(
          scale: _pulseController,
          child: const _VerificationBadge(),
        ),
        const SizedBox(height: 24),
        const Text(
          'Verifying your account...',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _navy,
            fontSize: 25,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          "Please wait, we're confirming\nyour details.",
          textAlign: TextAlign.center,
          style: TextStyle(color: _muted, fontSize: 14, height: 1.4),
        ),
        const SizedBox(height: 24),
        const SizedBox(
          width: 165,
          child: LinearProgressIndicator(
            minHeight: 5,
            borderRadius: BorderRadius.all(Radius.circular(10)),
            color: _purple,
            backgroundColor: Color(0xFFE3E5F5),
          ),
        ),
        const Spacer(),
        const _BottomInfoCard(
          icon: Icons.lock_rounded,
          title: 'Almost there!',
          subtitle: 'Setting up your account securely.',
        ),
      ],
    );
  }

  Widget _topBar({bool showBack = true}) {
    return SizedBox(
      height: 44,
      child: Align(
        alignment: Alignment.centerLeft,
        child: AnimatedOpacity(
          opacity: showBack ? 1 : 0,
          duration: const Duration(milliseconds: 180),
          child: IgnorePointer(
            ignoring: !showBack,
            child: IconButton(
              onPressed: () => Navigator.maybePop(context),
              padding: EdgeInsets.zero,
              alignment: Alignment.centerLeft,
              icon: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: _navy,
                size: 21,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _otpFields() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(6, (index) {
        return Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: index == 5 ? 0 : 7),
            child: SizedBox(
              height: 62,
              child: TextField(
                controller: _controllers[index],
                focusNode: _focusNodes[index],
                enabled: !_isVerifying,
                autofocus: index == 0,
                textAlign: TextAlign.center,
                keyboardType: TextInputType.number,
                textInputAction: index == 5
                    ? TextInputAction.done
                    : TextInputAction.next,
                autofillHints: index == 0
                    ? const [AutofillHints.oneTimeCode]
                    : null,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(1),
                ],
                style: const TextStyle(
                  color: _navy,
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
                cursorColor: _purple,
                onChanged: (value) => _onDigitChanged(index, value),
                onTap: () {
                  _controllers[index].selection = TextSelection(
                    baseOffset: 0,
                    extentOffset: _controllers[index].text.length,
                  );
                },
                decoration: InputDecoration(
                  counterText: '',
                  filled: true,
                  fillColor: Colors.white.withValues(alpha: .96),
                  contentPadding: EdgeInsets.zero,
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFFE1E4EF)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: _purple, width: 1.6),
                  ),
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: const BorderSide(color: Color(0xFFE1E4EF)),
                  ),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _resendRow() {
    return Wrap(
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.center,
      spacing: 5,
      children: [
        const Text(
          "Didn't receive the code?",
          style: TextStyle(color: _muted, fontSize: 13),
        ),
        GestureDetector(
          onTap: _resendOtp,
          child: Text(
            _secondsRemaining == 0 ? 'Resend now' : 'Resend in $_timerText',
            style: TextStyle(
              color: _purple,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              decoration: _secondsRemaining == 0
                  ? TextDecoration.underline
                  : TextDecoration.none,
            ),
          ),
        ),
      ],
    );
  }
}

class _BrandHeader extends StatelessWidget {
  const _BrandHeader();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: 92,
          height: 92,
          child: Image.asset(
            'assets/icon/dhanviq_icon.png',
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'DHANVIQ',
          style: TextStyle(
            color: _navy,
            fontSize: 28,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.3,
          ),
        ),
        const Text(
          'Track  •  Save  •  Grow',
          style: TextStyle(color: _muted, fontSize: 11.5, letterSpacing: 1.15),
        ),
      ],
    );
  }
}

class _VerificationBadge extends StatelessWidget {
  const _VerificationBadge();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 200,
      height: 200,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 200,
            height: 200,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0x1219D7B0),
            ),
          ),
          Container(
            width: 142,
            height: 142,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Color(0x2619D7B0),
            ),
          ),
          Container(
            width: 96,
            height: 96,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF31E1B9), Color(0xFF0BBE8E)],
              ),
              boxShadow: [
                BoxShadow(
                  color: Color(0x4019D7B0),
                  blurRadius: 24,
                  offset: Offset(0, 10),
                ),
              ],
            ),
            child: const Icon(
              Icons.check_rounded,
              color: Colors.white,
              size: 55,
            ),
          ),
          for (final alignment in const [
            Alignment(-.92, -.72),
            Alignment(.88, -.64),
            Alignment(-.88, .70),
            Alignment(.92, .64),
          ])
            Align(
              alignment: alignment,
              child: Container(
                width: 9,
                height: 9,
                decoration: const BoxDecoration(
                  color: _mint,
                  shape: BoxShape.circle,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _BottomInfoCard extends StatelessWidget {
  const _BottomInfoCard({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .76),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withValues(alpha: .85)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0x126C3BFF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: _purple, size: 26),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: _navy,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(
                    color: _muted,
                    fontSize: 11.5,
                    height: 1.25,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OtpBackground extends StatelessWidget {
  const _OtpBackground();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFBFBFF), Color(0xFFF7F9FF), Color(0xFFF4FAFC)],
            ),
          ),
        ),
        Positioned(
          top: -150,
          left: -115,
          child: _blob(310, _purple, .09, -.35),
        ),
        Positioned(top: 120, right: -170, child: _blob(370, _mint, .075, .3)),
        Positioned(
          bottom: -155,
          left: -105,
          child: _blob(390, const Color(0xFF5A8DFF), .12, .45),
        ),
        Positioned(
          bottom: -135,
          right: -120,
          child: _blob(360, _purple, .11, -.4),
        ),
      ],
    );
  }

  static Widget _blob(double size, Color color, double opacity, double angle) {
    return Transform.rotate(
      angle: angle + math.pi / 18,
      child: Container(
        width: size,
        height: size * .68,
        decoration: BoxDecoration(
          color: color.withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(size * .34),
        ),
      ),
    );
  }
}
