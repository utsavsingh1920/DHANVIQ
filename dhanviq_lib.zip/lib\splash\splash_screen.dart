import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../navigation/main_navigation_screen.dart';
import '../onboarding/onboarding_screen.dart';
import '../welcome/welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const Color _navy = Color(0xFF071536);

  late final AnimationController _controller;
  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _slideAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.82,
      end: 1,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutBack));

    _slideAnimation = Tween<double>(
      begin: 24,
      end: 0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));

    _controller.forward();

    Timer(const Duration(milliseconds: 2600), () async {
      if (!mounted) return;

      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
      final onboardingCompleted = prefs.getBool('onboardingCompleted') ?? false;

      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        PageRouteBuilder<void>(
          transitionDuration: const Duration(milliseconds: 450),
          pageBuilder: (context, animation, secondaryAnimation) {
            return isLoggedIn
                ? const MainNavigationScreen()
                : onboardingCompleted
                    ? const WelcomeScreen()
                    : const OnboardingScreen();
          },
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            return FadeTransition(
              opacity: CurvedAnimation(
                parent: animation,
                curve: Curves.easeOut,
              ),
              child: child,
            );
          },
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.dark,
        systemNavigationBarColor: _navy,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: _navy,
        body: LayoutBuilder(
          builder: (context, constraints) {
            final screenHeight = constraints.maxHeight;
            final screenWidth = constraints.maxWidth;

            return Stack(
              fit: StackFit.expand,
              children: [
                const _BackgroundGlow(),

                const Positioned(top: 54, left: 28, child: _TopLeftText()),

                const Positioned(top: 50, right: 26, child: _TopRightText()),

                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  height: screenHeight * 0.38,
                  child: const RepaintBoundary(
                    child: CustomPaint(painter: _FinanceBackgroundPainter()),
                  ),
                ),

                SafeArea(
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: AnimatedBuilder(
                      animation: _slideAnimation,
                      builder: (context, child) {
                        return Transform.translate(
                          offset: Offset(0, _slideAnimation.value),
                          child: child,
                        );
                      },
                      child: Center(
                        child: Padding(
                          padding: EdgeInsets.only(
                            left: 24,
                            right: 24,
                            bottom: screenHeight * 0.13,
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              ScaleTransition(
                                scale: _scaleAnimation,
                                child: _AppLogo(
                                  size: screenWidth.clamp(320, 500) * 0.43,
                                ),
                              ),
                              const SizedBox(height: 25),
                              const _DhanviqTitle(),
                              const SizedBox(height: 8),
                              const _BrandSubtitle(),
                              const SizedBox(height: 24),
                              const _GradientDivider(),
                              const SizedBox(height: 28),
                              const _Tagline(),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _AppLogo extends StatelessWidget {
  const _AppLogo({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.24),
        boxShadow: const [
          BoxShadow(color: Color(0x552362FF), blurRadius: 30, spreadRadius: 2),
          BoxShadow(color: Color(0x3316E0B5), blurRadius: 36, spreadRadius: 1),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size * 0.24),
        child: Image.asset(
          'assets/icon/dhanviq_icon.png',
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              color: const Color(0xFF0B286D),
              alignment: Alignment.center,
              child: const Text(
                'D',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 72,
                  fontWeight: FontWeight.w900,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _DhanviqTitle extends StatelessWidget {
  const _DhanviqTitle();

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (bounds) {
        return const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            Colors.white,
            Colors.white,
            Color(0xFFB7F5EA),
            Color(0xFF16E0B5),
          ],
          stops: [0, 0.64, 0.83, 1],
        ).createShader(bounds);
      },
      child: const Text(
        'DHANVIQ',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Colors.white,
          fontSize: 39,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5,
          height: 1,
        ),
      ),
    );
  }
}

class _BrandSubtitle extends StatelessWidget {
  const _BrandSubtitle();

  @override
  Widget build(BuildContext context) {
    return const Text.rich(
      TextSpan(
        children: [
          TextSpan(text: 'Track'),
          TextSpan(
            text: '  •  ',
            style: TextStyle(color: Color(0xFF16E0B5)),
          ),
          TextSpan(text: 'Save'),
          TextSpan(
            text: '  •  ',
            style: TextStyle(color: Color(0xFF16E0B5)),
          ),
          TextSpan(text: 'Grow'),
        ],
      ),
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Color(0xFFB5BED5),
        fontSize: 15,
        fontWeight: FontWeight.w500,
        letterSpacing: 2,
      ),
    );
  }
}

class _GradientDivider extends StatelessWidget {
  const _GradientDivider();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 76,
      height: 3,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          colors: [Color(0xFF7846FF), Color(0xFF16E0B5)],
        ),
        boxShadow: const [BoxShadow(color: Color(0x667846FF), blurRadius: 10)],
      ),
    );
  }
}

class _Tagline extends StatelessWidget {
  const _Tagline();

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Text(
          'A Smarter You,',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFF1F3FA),
            fontSize: 20,
            height: 1.35,
            fontWeight: FontWeight.w500,
            fontStyle: FontStyle.italic,
          ),
        ),
        Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: 'Brighter ',
                style: TextStyle(color: Color(0xFF9A66FF)),
              ),
              TextSpan(
                text: 'Tomorrow.',
                style: TextStyle(color: Color(0xFF37D8F1)),
              ),
            ],
          ),
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 21,
            height: 1.35,
            fontWeight: FontWeight.w600,
            fontStyle: FontStyle.italic,
          ),
        ),
      ],
    );
  }
}

class _TopLeftText extends StatelessWidget {
  const _TopLeftText();

  @override
  Widget build(BuildContext context) {
    return const Opacity(
      opacity: 0.46,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Small Steps\nBigger Dreams',
            style: TextStyle(
              color: Color(0xFFAEB9D2),
              fontSize: 12,
              height: 1.25,
              letterSpacing: 0.6,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 11),
          SizedBox(
            width: 34,
            child: Divider(height: 1, thickness: 1, color: Color(0xFFAEB9D2)),
          ),
        ],
      ),
    );
  }
}

class _TopRightText extends StatelessWidget {
  const _TopRightText();

  @override
  Widget build(BuildContext context) {
    return Transform.rotate(
      angle: -0.16,
      child: const Opacity(
        opacity: 0.12,
        child: Text(
          'Better\nMoney\nBrighter\nYou',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFF8A9FCC),
            fontSize: 17,
            height: 1.05,
            fontStyle: FontStyle.italic,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _BackgroundGlow extends StatelessWidget {
  const _BackgroundGlow();

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: 130,
          left: -120,
          child: Container(
            width: 280,
            height: 280,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [Color(0x182463FF), Colors.transparent],
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 100,
          right: -130,
          child: Container(
            width: 330,
            height: 330,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [Color(0x1A16E0B5), Colors.transparent],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _FinanceBackgroundPainter extends CustomPainter {
  const _FinanceBackgroundPainter();

  @override
  void paint(Canvas canvas, Size size) {
    _drawBars(canvas, size);
    _drawGrowthLine(canvas, size);
    _drawBackWave(canvas, size);
    _drawFrontWave(canvas, size);
  }

  void _drawBars(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [Color(0x001B69DD), Color(0x552B68ED)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final barWidth = size.width * 0.052;
    final gap = size.width * 0.035;
    final startingX = size.width * 0.52;
    final baseY = size.height * 0.72;

    final heights = [
      size.height * 0.18,
      size.height * 0.25,
      size.height * 0.36,
      size.height * 0.49,
    ];

    for (var index = 0; index < heights.length; index++) {
      final x = startingX + index * (barWidth + gap);
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(x, baseY - heights[index], barWidth, heights[index]),
        const Radius.circular(4),
      );

      canvas.drawRRect(rect, paint);
    }
  }

  void _drawGrowthLine(Canvas canvas, Size size) {
    final linePath = Path()
      ..moveTo(size.width * 0.08, size.height * 0.67)
      ..cubicTo(
        size.width * 0.22,
        size.height * 0.61,
        size.width * 0.28,
        size.height * 0.34,
        size.width * 0.44,
        size.height * 0.32,
      )
      ..cubicTo(
        size.width * 0.57,
        size.height * 0.30,
        size.width * 0.62,
        size.height * 0.48,
        size.width * 0.74,
        size.height * 0.35,
      )
      ..cubicTo(
        size.width * 0.84,
        size.height * 0.25,
        size.width * 0.87,
        size.height * 0.10,
        size.width * 0.94,
        size.height * 0.07,
      );

    final glowPaint = Paint()
      ..color = const Color(0x5529BFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    final linePaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFF7550FF), Color(0xFF24C8FF)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(linePath, glowPaint);
    canvas.drawPath(linePath, linePaint);

    final point = Offset(size.width * 0.94, size.height * 0.07);

    canvas.drawCircle(
      point,
      17,
      Paint()
        ..color = const Color(0x5539D7FF)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );

    canvas.drawCircle(
      point,
      9,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFF7F58FF), Color(0xFF42E0ED)],
        ).createShader(Rect.fromCircle(center: point, radius: 9)),
    );

    canvas.drawCircle(
      point,
      9,
      Paint()
        ..color = const Color(0xFFDDFBFF)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );
  }

  void _drawBackWave(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, size.height * 0.62)
      ..cubicTo(
        size.width * 0.18,
        size.height * 0.44,
        size.width * 0.36,
        size.height * 0.49,
        size.width * 0.53,
        size.height * 0.67,
      )
      ..cubicTo(
        size.width * 0.70,
        size.height * 0.85,
        size.width * 0.84,
        size.height * 0.69,
        size.width,
        size.height * 0.57,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF7044FA), Color(0xFF5221CE), Color(0xFF153981)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final glowPaint = Paint()
      ..color = const Color(0x557A45FF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 9
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);

    canvas.drawPath(path, glowPaint);
    canvas.drawPath(path, paint);
  }

  void _drawFrontWave(Canvas canvas, Size size) {
    final path = Path()
      ..moveTo(0, size.height * 0.77)
      ..cubicTo(
        size.width * 0.18,
        size.height * 0.67,
        size.width * 0.28,
        size.height * 0.48,
        size.width * 0.45,
        size.height * 0.48,
      )
      ..cubicTo(
        size.width * 0.62,
        size.height * 0.48,
        size.width * 0.72,
        size.height * 0.72,
        size.width * 0.87,
        size.height * 0.75,
      )
      ..cubicTo(
        size.width * 0.92,
        size.height * 0.76,
        size.width * 0.96,
        size.height * 0.72,
        size.width,
        size.height * 0.70,
      )
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();

    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF244EB1), Color(0xFF102E70), Color(0xFF071536)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final topBorderPath = Path()
      ..moveTo(0, size.height * 0.77)
      ..cubicTo(
        size.width * 0.18,
        size.height * 0.67,
        size.width * 0.28,
        size.height * 0.48,
        size.width * 0.45,
        size.height * 0.48,
      )
      ..cubicTo(
        size.width * 0.62,
        size.height * 0.48,
        size.width * 0.72,
        size.height * 0.72,
        size.width * 0.87,
        size.height * 0.75,
      )
      ..cubicTo(
        size.width * 0.92,
        size.height * 0.76,
        size.width * 0.96,
        size.height * 0.72,
        size.width,
        size.height * 0.70,
      );

    final borderPaint = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFF42BDFF), Color(0xFF794DFF), Color(0xFF1B65D8)],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawPath(path, paint);
    canvas.drawPath(topBorderPath, borderPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
