import 'package:flutter/material.dart';

class UI {
  static const purple = Color(0xFF6C3BFF), navy = Color(0xFF071536);
  static bool dark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
  static Color bg(BuildContext c) =>
      dark(c) ? const Color(0xFF090F20) : const Color(0xFFF7F8FD);
  static Color card(BuildContext c) =>
      dark(c) ? const Color(0xFF172138) : Colors.white;
  static Color ink(BuildContext c) => dark(c) ? Colors.white : navy;
  static Color sub(BuildContext c) =>
      dark(c) ? const Color(0xFFADB7CD) : const Color(0xFF77839A);
  static Color border(BuildContext c) =>
      dark(c) ? const Color(0xFF303B53) : const Color(0xFFE8EBF3);
  static void go(BuildContext c, Widget w) =>
      Navigator.push(c, MaterialPageRoute<void>(builder: (_) => w));
  static void toast(BuildContext c, String s) =>
      ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(s)));
}

class SPage extends StatelessWidget {
  const SPage({
    super.key,
    required this.title,
    required this.children,
    this.subtitle,
  });
  final String title;
  final String? subtitle;
  final List<Widget> children;
  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: UI.bg(c),
    appBar: AppBar(
      centerTitle: true,
      backgroundColor: UI.bg(c),
      foregroundColor: UI.ink(c),
      title: Text(
        title,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      ),
    ),
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 36),
        children: [
          if (subtitle != null) ...[
            Text(subtitle!, style: TextStyle(color: UI.sub(c), height: 1.5)),
            const SizedBox(height: 16),
          ],
          ...children,
        ],
      ),
    ),
  );
}

class SCard extends StatelessWidget {
  const SCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(15),
  });
  final Widget child;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext c) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: UI.card(c),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: UI.border(c)),
    ),
    child: child,
  );
}

class STitle extends StatelessWidget {
  const STitle(this.value, {super.key});
  final String value;
  @override
  Widget build(BuildContext c) => Padding(
    padding: const EdgeInsets.fromLTRB(3, 18, 0, 10),
    child: Text(
      value,
      style: TextStyle(
        color: UI.ink(c),
        fontSize: 14,
        fontWeight: FontWeight.w800,
      ),
    ),
  );
}

class SRow extends StatelessWidget {
  const SRow({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.onTap,
    this.trailing,
  });
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  final Widget? trailing;
  @override
  Widget build(BuildContext c) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 2),
    leading: Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: UI.purple.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        color: UI.dark(c) ? const Color(0xFFBBA7FF) : UI.purple,
        size: 21,
      ),
    ),
    title: Text(
      title,
      style: TextStyle(
        color: UI.ink(c),
        fontWeight: FontWeight.w700,
        fontSize: 13,
      ),
    ),
    subtitle: subtitle == null
        ? null
        : Text(subtitle!, style: TextStyle(color: UI.sub(c), fontSize: 11)),
    trailing: trailing ?? Icon(Icons.chevron_right_rounded, color: UI.sub(c)),
    onTap: onTap,
  );
}

class SButton extends StatelessWidget {
  const SButton(
    this.label,
    this.onTap, {
    super.key,
    this.icon = Icons.check_rounded,
  });
  final String label;
  final VoidCallback? onTap;
  final IconData icon;
  @override
  Widget build(BuildContext c) => SizedBox(
    width: double.infinity,
    height: 52,
    child: FilledButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(label),
      style: FilledButton.styleFrom(
        backgroundColor: UI.purple,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
  );
}
