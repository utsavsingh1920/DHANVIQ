import 'package:flutter/material.dart';

import 'profile_screen.dart';
import 'profile_service.dart';
import 'settings_ui.dart';

class AccountDetailsScreen extends StatelessWidget {
  const AccountDetailsScreen({super.key});
  @override
  Widget build(BuildContext c) => SPage(
    title: 'Account Settings',
    subtitle: 'Keep your personal information up to date.',
    children: [
      AnimatedBuilder(
        animation: ProfileService.instance,
        builder: (c, _) => SCard(
          child: Column(
            children: [
              const CircleAvatar(
                radius: 30,
                backgroundColor: Color(0xFFECE6FF),
                child: Icon(Icons.person, color: UI.purple, size: 33),
              ),
              const SizedBox(height: 9),
              Text(
                ProfileService.instance.name,
                style: TextStyle(
                  color: UI.ink(c),
                  fontWeight: FontWeight.w800,
                  fontSize: 17,
                ),
              ),
              Text(
                ProfileService.instance.email,
                style: TextStyle(color: UI.sub(c)),
              ),
            ],
          ),
        ),
      ),
      const STitle('PERSONAL DETAILS'),
      SCard(
        child: SRow(
          icon: Icons.edit_outlined,
          title: 'Edit Profile',
          subtitle: 'Name, email, phone and more',
          onTap: () => UI.go(c, const ProfileScreen()),
        ),
      ),
      const STitle('ACCOUNT INFORMATION'),
      SCard(
        child: const SRow(
          icon: Icons.info_outline,
          title: 'Local account',
          subtitle: 'Your financial records are stored on this device',
          trailing: Icon(Icons.phone_android_outlined, color: UI.purple),
        ),
      ),
    ],
  );
}
