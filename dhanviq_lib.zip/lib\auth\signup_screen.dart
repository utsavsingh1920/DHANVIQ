import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'login_screen.dart';
import 'otp_verification_screen.dart';

const _navy = Color(0xFF101936);
const _purple = Color(0xFF6C3BFF);
const _muted = Color(0xFF747D94);
const _background = Color(0xFFF8F9FE);

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _hidePassword = true;
  bool _accepted = true;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _openLogin() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
    );
  }

  void _createAccount() {
    FocusScope.of(context).unfocus();
    if (!_accepted) {
      _message('Please accept the Terms of Service and Privacy Policy.');
      return;
    }
    if (!(_formKey.currentState?.validate() ?? false)) return;
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => OtpVerificationScreen(
          phoneNumber: '+91 ${_phoneController.text.trim()}',
        ),
      ),
    );
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: _background,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: _background,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: _background,
        body: Stack(
          children: [
            const Positioned.fill(child: _Background()),
            SafeArea(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.center,
                      child: SizedBox(
                        width: constraints.maxWidth,
                        height: 790,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(25, 6, 25, 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              _topBar(),
                              Expanded(
                                child: Form(
                                  key: _formKey,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const _Brand(),
                                      const SizedBox(height: 8),
                                      const Text(
                                        'Create Account',
                                        style: TextStyle(
                                          color: _navy,
                                          fontSize: 25,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: -.4,
                                        ),
                                      ),
                                      const SizedBox(height: 3),
                                      const Text(
                                        'Start your journey towards a smarter\nfinancial future.',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: _muted,
                                          fontSize: 12.5,
                                          height: 1.3,
                                        ),
                                      ),
                                      const SizedBox(height: 12),
                                      _field(
                                        controller: _nameController,
                                        label: 'Full Name',
                                        hint: 'Enter your full name',
                                        icon: Icons.person_outline_rounded,
                                        capitalization:
                                            TextCapitalization.words,
                                        validator: (value) =>
                                            (value ?? '').trim().length < 3
                                            ? 'Enter your full name'
                                            : null,
                                      ),
                                      const SizedBox(height: 7),
                                      _field(
                                        controller: _emailController,
                                        label: 'Email Address',
                                        hint: 'you@example.com',
                                        icon: Icons.mail_outline_rounded,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        validator: (value) {
                                          final email = value?.trim() ?? '';
                                          return email.isEmpty ||
                                                  !email.contains('@')
                                              ? 'Enter a valid email address'
                                              : null;
                                        },
                                      ),
                                      const SizedBox(height: 7),
                                      _field(
                                        controller: _phoneController,
                                        label: 'Mobile Number',
                                        hint: '+91 98765 43210',
                                        icon: Icons.phone_outlined,
                                        keyboardType: TextInputType.phone,
                                        inputFormatters: [
                                          FilteringTextInputFormatter
                                              .digitsOnly,
                                          LengthLimitingTextInputFormatter(10),
                                        ],
                                        validator: (value) =>
                                            (value ?? '').length != 10
                                            ? 'Enter a valid mobile number'
                                            : null,
                                      ),
                                      const SizedBox(height: 7),
                                      _field(
                                        controller: _passwordController,
                                        label: 'Create Password',
                                        hint: 'Minimum 6 characters',
                                        icon: Icons.lock_outline_rounded,
                                        obscureText: _hidePassword,
                                        suffix: IconButton(
                                          onPressed: () => setState(
                                            () =>
                                                _hidePassword = !_hidePassword,
                                          ),
                                          icon: Icon(
                                            _hidePassword
                                                ? Icons.visibility_outlined
                                                : Icons.visibility_off_outlined,
                                            color: _muted,
                                          ),
                                        ),
                                        validator: (value) =>
                                            (value ?? '').length < 6
                                            ? 'Minimum 6 characters required'
                                            : null,
                                      ),
                                      const SizedBox(height: 8),
                                      _termsRow(),
                                      const SizedBox(height: 9),
                                      _primaryButton(),
                                      const SizedBox(height: 10),
                                      _divider(),
                                      const SizedBox(height: 9),
                                      _socialRow(),
                                      const SizedBox(height: 10),
                                      _infoCard(),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topBar() {
    return SizedBox(
      height: 44,
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.maybePop(context),
            padding: EdgeInsets.zero,
            alignment: Alignment.centerLeft,
            icon: const Icon(
              Icons.arrow_back_ios_new_rounded,
              color: _navy,
              size: 21,
            ),
          ),
          const Spacer(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Already have an account?',
                style: TextStyle(color: _muted, fontSize: 11.5),
              ),
              GestureDetector(
                onTap: _openLogin,
                child: const Text(
                  'Login',
                  style: TextStyle(
                    color: _purple,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType? keyboardType,
    TextCapitalization capitalization = TextCapitalization.none,
    List<TextInputFormatter>? inputFormatters,
    bool obscureText = false,
    Widget? suffix,
    String? Function(String?)? validator,
  }) {
    return Container(
      height: 53,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .94),
        borderRadius: BorderRadius.circular(17),
        boxShadow: const [
          BoxShadow(
            color: Color(0x126C3BFF),
            blurRadius: 16,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        textCapitalization: capitalization,
        inputFormatters: inputFormatters,
        obscureText: obscureText,
        validator: validator,
        style: const TextStyle(
          color: _navy,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: const Color(0xFF5E6987), size: 22),
          suffixIcon: suffix,
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
            color: Color(0xFF43506F),
            fontSize: 11.5,
            fontWeight: FontWeight.w600,
          ),
          hintStyle: const TextStyle(color: _muted, fontSize: 12),
          errorStyle: const TextStyle(fontSize: 0, height: 0),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 7),
        ),
      ),
    );
  }

  Widget _termsRow() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => setState(() => _accepted = !_accepted),
          child: Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: _accepted ? _purple : Colors.white,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: _accepted ? _purple : const Color(0xFFC8CDDA),
              ),
            ),
            child: _accepted
                ? const Icon(Icons.check_rounded, color: Colors.white, size: 16)
                : null,
          ),
        ),
        const SizedBox(width: 8),
        const Expanded(
          child: Text.rich(
            TextSpan(
              children: [
                TextSpan(text: 'I agree to the '),
                TextSpan(
                  text: 'Terms of Service',
                  style: TextStyle(
                    color: _purple,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                  ),
                ),
                TextSpan(text: ' and '),
                TextSpan(
                  text: 'Privacy Policy.',
                  style: TextStyle(
                    color: _purple,
                    fontWeight: FontWeight.w600,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ],
            ),
            style: TextStyle(color: _muted, fontSize: 10.5),
          ),
        ),
      ],
    );
  }

  Widget _primaryButton() {
    return Container(
      width: double.infinity,
      height: 51,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF8150FF), Color(0xFF6329EF)],
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: const [
          BoxShadow(
            color: Color(0x3D6C3BFF),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _createAccount,
          borderRadius: BorderRadius.circular(18),
          child: const Row(
            children: [
              SizedBox(width: 42),
              Expanded(
                child: Text(
                  'Create Account',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 18),
                child: Icon(
                  Icons.arrow_forward_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _divider() {
    return const Row(
      children: [
        Expanded(child: Divider(color: Color(0xFFCFD4E2))),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 12),
          child: Text(
            'or sign up with',
            style: TextStyle(color: _muted, fontSize: 11.5),
          ),
        ),
        Expanded(child: Divider(color: Color(0xFFCFD4E2))),
      ],
    );
  }

  Widget _socialRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _socialButton(
          const Text(
            'G',
            style: TextStyle(
              color: Color(0xFF4285F4),
              fontSize: 21,
              fontWeight: FontWeight.w900,
            ),
          ),
          'Google Sign Up',
        ),
        const SizedBox(width: 20),
        _socialButton(
          const Icon(Icons.apple_rounded, color: _navy, size: 27),
          'Apple Sign Up',
        ),
        const SizedBox(width: 20),
        _socialButton(
          const Icon(Icons.mail_rounded, color: _navy, size: 23),
          'Email Sign Up',
        ),
      ],
    );
  }

  Widget _socialButton(Widget child, String message) {
    return Material(
      color: Colors.white,
      elevation: 2,
      shadowColor: const Color(0x226C3BFF),
      borderRadius: BorderRadius.circular(17),
      child: InkWell(
        onTap: () => _message(message),
        borderRadius: BorderRadius.circular(17),
        child: SizedBox(width: 52, height: 48, child: Center(child: child)),
      ),
    );
  }

  Widget _infoCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .72),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withValues(alpha: .8)),
      ),
      child: const Row(
        children: [
          Icon(Icons.group_rounded, color: _purple, size: 26),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Build a smarter financial future.',
                  style: TextStyle(
                    color: _navy,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Join thousands who are already growing with DHANVIQ.',
                  style: TextStyle(color: _muted, fontSize: 10.5, height: 1.25),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Brand extends StatelessWidget {
  const _Brand();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          width: 76,
          height: 76,
          child: Image.asset(
            'assets/icon/dhanviq_icon.png',
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
          ),
        ),
        const SizedBox(height: 3),
        const Text(
          'DHANVIQ',
          style: TextStyle(
            color: _navy,
            fontSize: 24,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.3,
          ),
        ),
        const Text(
          'Track  •  Save  •  Grow',
          style: TextStyle(color: _muted, fontSize: 10.5, letterSpacing: 1.1),
        ),
      ],
    );
  }
}

class _Background extends StatelessWidget {
  const _Background();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFBFBFF), Color(0xFFF7F9FF), Color(0xFFF4FAFC)],
            ),
          ),
        ),
        Positioned(
          top: -150,
          left: -115,
          child: _blob(310, _purple, .07, -.35),
        ),
        Positioned(
          top: 120,
          right: -170,
          child: _blob(370, const Color(0xFF19D7B0), .065, .3),
        ),
        Positioned(
          bottom: -155,
          left: -105,
          child: _blob(390, const Color(0xFF5A8DFF), .10, .45),
        ),
        Positioned(
          bottom: -135,
          right: -120,
          child: _blob(360, _purple, .09, -.4),
        ),
      ],
    );
  }

  static Widget _blob(double size, Color color, double opacity, double angle) {
    return Transform.rotate(
      angle: angle + math.pi / 18,
      child: Container(
        width: size,
        height: size * .68,
        decoration: BoxDecoration(
          color: color.withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(size * .34),
        ),
      ),
    );
  }
}
