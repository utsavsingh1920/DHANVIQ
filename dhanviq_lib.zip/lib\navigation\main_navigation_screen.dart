import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../home/home_screen.dart';
import '../goals/goals_screen.dart';
import '../settings/settings_screen.dart';
import '../insights/insights_screen.dart';
import '../transactions/transactions_screen.dart';
import '../models/transaction_model.dart';
import '../services/transaction_service.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  static const _navy = Color(0xFF101936);
  static const _purple = Color(0xFF6C3BFF);
  static const _muted = Color(0xFF747D94);
  static const _background = Color(0xFFF7F8FD);

  int _selectedIndex = 0;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      HomeScreen(showNavigation: false, onNavigationTap: _onHomeNavigationTap),
      TransactionsScreen(onAdd: _openAddSheet),
      const SizedBox.shrink(),
      const InsightsScreen(),
      const SettingsScreen(),
    ];
  }

  // The existing Home screen still uses the previous tab indexes:
  // Goals = 3 and Insights = 4. Keep those shortcuts working.
  void _onHomeNavigationTap(int index) {
    if (index == 3) {
      Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => const GoalsScreen()),
      );
      return;
    }
    if (index == 4) {
      _selectTab(3);
      return;
    }
    _selectTab(index);
  }

  void _selectTab(int index) {
    if (index == 2) {
      _openAddSheet();
      return;
    }
    if (index < 0 || index >= _pages.length) return;
    setState(() => _selectedIndex = index);
  }

  void _openAddSheet() {
    showModalBottomSheet<void>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _AddTransactionSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: Colors.white,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        extendBody: true,
        backgroundColor: _background,
        body: IndexedStack(index: _selectedIndex, children: _pages),
        bottomNavigationBar: _MainBottomNavigation(
          selectedIndex: _selectedIndex,
          onTap: _selectTab,
        ),
      ),
    );
  }
}

class _MainBottomNavigation extends StatelessWidget {
  const _MainBottomNavigation({
    required this.selectedIndex,
    required this.onTap,
  });

  final int selectedIndex;
  final ValueChanged<int> onTap;

  static const _items = [
    (Icons.home_rounded, 'Home'),
    (Icons.swap_horiz_rounded, 'Transactions'),
    (Icons.add_rounded, ''),
    (Icons.bar_chart_rounded, 'Insights'),
    (Icons.settings_outlined, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return Container(
      height: 66 + bottomInset,
      padding: EdgeInsets.only(bottom: bottomInset, left: 4, right: 4),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Color(0x1F101936),
            blurRadius: 22,
            offset: Offset(0, -5),
          ),
        ],
      ),
      child: Row(
        children: List.generate(_items.length, (index) {
          if (index == 2) {
            return Expanded(
              child: Center(
                child: _AddButton(onTap: () => onTap(2)),
              ),
            );
          }

          final selected = selectedIndex == index;
          return Expanded(
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => onTap(index),
                child: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        width: 42,
                        height: 32,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: selected
                              ? const Color(0x126C3BFF)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(
                          selected ? _selectedIcon(index) : _items[index].$1,
                          color: selected
                              ? _MainNavigationScreenState._purple
                              : _MainNavigationScreenState._muted,
                          size: 21,
                        ),
                      ),
                      const SizedBox(height: 1),
                      Text(
                        _items[index].$2,
                        maxLines: 1,
                        style: TextStyle(
                          color: selected
                              ? _MainNavigationScreenState._purple
                              : _MainNavigationScreenState._muted,
                          fontSize: 9,
                          fontWeight: selected
                              ? FontWeight.w700
                              : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  IconData _selectedIcon(int index) {
    return switch (index) {
      0 => Icons.home_rounded,
      1 => Icons.swap_horiz_rounded,
      3 => Icons.bar_chart_rounded,
      4 => Icons.settings_rounded,
      _ => Icons.circle,
    };
  }
}

class _AddButton extends StatelessWidget {
  const _AddButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52,
      height: 52,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF8652FF), Color(0xFF5B25E8)],
        ),
        boxShadow: [
          BoxShadow(
            color: Color(0x556C3BFF),
            blurRadius: 16,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          customBorder: const CircleBorder(),
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 29),
        ),
      ),
    );
  }
}

class _AddTransactionSheet extends StatelessWidget {
  const _AddTransactionSheet();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      decoration: const BoxDecoration(
        color: Color(0xFFF9F9FE),
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 42,
            height: 4,
            decoration: BoxDecoration(
              color: const Color(0xFFD8DBE6),
              borderRadius: BorderRadius.circular(20),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Add Transaction',
            style: TextStyle(
              color: _MainNavigationScreenState._navy,
              fontSize: 21,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 5),
          const Text(
            'What would you like to record?',
            style: TextStyle(
              color: _MainNavigationScreenState._muted,
              fontSize: 12.5,
            ),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              Expanded(
                child: _TransactionOption(
                  icon: Icons.add_rounded,
                  title: 'Add Income',
                  subtitle: 'Salary, bonus or other income',
                  color: const Color(0xFF16CFA5),
                  background: const Color(0xFFE1FAF3),
                  onTap: () => _openForm(context, true),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _TransactionOption(
                  icon: Icons.remove_rounded,
                  title: 'Add Expense',
                  subtitle: 'Food, bills or other spending',
                  color: const Color(0xFFFF4D82),
                  background: const Color(0xFFFFE6EF),
                  onTap: () => _openForm(context, false),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }

  void _openForm(BuildContext context, bool isIncome) {
    final navigator = Navigator.of(context);
    navigator.pop();
    navigator.push(
      MaterialPageRoute<void>(
        builder: (_) => AddTransactionForm(isIncome: isIncome),
      ),
    );
  }
}

class _TransactionOption extends StatelessWidget {
  const _TransactionOption({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.background,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final Color background;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 154,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE9EAF2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: background,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: color, size: 27),
              ),
              const Spacer(),
              Text(
                title,
                style: const TextStyle(
                  color: _MainNavigationScreenState._navy,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                maxLines: 2,
                style: const TextStyle(
                  color: _MainNavigationScreenState._muted,
                  fontSize: 10.5,
                  height: 1.25,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AddTransactionForm extends StatefulWidget {
  const AddTransactionForm({super.key, required this.isIncome, this.existing});
  final TransactionModel? existing;

  final bool isIncome;

  @override
  State<AddTransactionForm> createState() => _AddTransactionFormState();
}

class _AddTransactionFormState extends State<AddTransactionForm> {
  late bool isIncome = widget.existing?.isIncome ?? widget.isIncome;
  final amountController = TextEditingController();
  final noteController = TextEditingController();
  late String category = widget.existing?.category ?? (widget.isIncome ? 'Salary' : 'Food');
  String paymentMethod = 'Cash';
  DateTime selectedDate = DateTime.now();
  bool isSaving = false;
  String get date => '${selectedDate.day} ${_month(selectedDate.month)} ${selectedDate.year}';

  @override
  void initState() {
    super.initState();
    final item = widget.existing;
    if (item != null) {
      amountController.text = item.amount.toStringAsFixed(item.amount % 1 == 0 ? 0 : 2);
      noteController.text = item.note;
      paymentMethod = item.paymentMethod;
      selectedDate = item.date;
    }
  }

  @override
  void dispose() {
    amountController.dispose();
    noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final accent = isIncome ? const Color(0xFF16B981) : const Color(0xFFFF3D6E);

    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FD),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7F8FD),
        foregroundColor: _MainNavigationScreenState._navy,
        elevation: 0,
        title: Text(
          widget.existing != null ? 'Edit Transaction' : (isIncome ? 'Add Income' : 'Add Expense'),
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
          children: [
            _typeSwitch(),
            const SizedBox(height: 25),
            _fieldLabel('Amount'),
            const SizedBox(height: 7),
            TextField(
              controller: amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Color(0xFF101936)),
              decoration: _inputDecoration('₹0', Icons.calculate_outlined),
            ),
            const SizedBox(height: 22),
            _fieldLabel('Category'),
            const SizedBox(height: 7),
            _selectTile(
              icon: isIncome ? Icons.business_center_rounded : Icons.restaurant_rounded,
              color: isIncome ? const Color(0xFF16B981) : const Color(0xFFFF3D6E),
              title: category,
              onTap: _chooseCategory,
            ),
            const SizedBox(height: 18),
            _fieldLabel('Date'),
            const SizedBox(height: 7),
            _selectTile(icon: Icons.calendar_month_outlined, color: _MainNavigationScreenState._navy, title: date, onTap: _chooseDate),
            const SizedBox(height: 18),
            _fieldLabel('Payment Method'),
            const SizedBox(height: 7),
            _selectTile(icon: Icons.account_balance_wallet_outlined, color: _MainNavigationScreenState._navy, title: paymentMethod, onTap: _choosePayment),
            const SizedBox(height: 18),
            _fieldLabel('Note (Optional)'),
            const SizedBox(height: 7),
            TextField(
              controller: noteController,
              decoration: _inputDecoration('Add a note...', Icons.note_alt_outlined).copyWith(suffixIcon: null),
            ),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: isSaving ? null : _save,
              style: FilledButton.styleFrom(
                backgroundColor: accent,
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              ),
              child: isSaving
                    ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                    : Text(widget.existing != null ? 'Save Changes' : (isIncome ? 'Save Income' : 'Save Expense'), style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _typeSwitch() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: const Color(0xFFECEFF8), borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Expanded(child: _typeButton(false, 'Expense')),
          Expanded(child: _typeButton(true, 'Income')),
        ],
      ),
    );
  }

  Widget _typeButton(bool income, String label) {
    final selected = income == isIncome;
    return GestureDetector(
      onTap: () => setState(() {
        isIncome = income;
        category = income ? 'Salary' : 'Food';
      }),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(color: selected ? (income ? const Color(0xFF16B981) : const Color(0xFFFF3D6E)) : Colors.transparent, borderRadius: BorderRadius.circular(9)),
        child: Text(label, textAlign: TextAlign.center, style: TextStyle(color: selected ? Colors.white : const Color(0xFF506080), fontWeight: FontWeight.w800)),
      ),
    );
  }

  Widget _fieldLabel(String label) => Text(label, style: const TextStyle(color: Color(0xFF101936), fontSize: 13, fontWeight: FontWeight.w800));

  InputDecoration _inputDecoration(String hint, IconData icon) => InputDecoration(
        hintText: hint,
        prefixIcon: Icon(icon, color: const Color(0xFF101936)),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE7EAF3))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFF6C3BFF), width: 1.5)),
      );

  Widget _selectTile({required IconData icon, required Color color, required String title, required VoidCallback onTap}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFE7EAF3))),
          child: Row(children: [Icon(icon, color: color, size: 22), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(color: Color(0xFF101936), fontWeight: FontWeight.w600))), const Icon(Icons.chevron_right_rounded, color: Color(0xFF747D94))]),
        ),
      );

  void _chooseCategory() {
    final options = isIncome ? ['Salary', 'Freelance', 'Bonus', 'Investments', 'Other'] : ['Food', 'Shopping', 'Transport', 'Bills', 'Entertainment', 'Health', 'Travel', 'Education', 'Other'];
    showModalBottomSheet<void>(context: context, builder: (_) => _ChoiceSheet(title: 'Select Category', options: options, selected: category, onSelected: (value) => setState(() => category = value)));
  }

  Future<void> _chooseDate() async {
    final pickedDate = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: selectedDate,
    );
    if (!mounted || pickedDate == null) return;
    setState(() => selectedDate = pickedDate);
  }

  void _choosePayment() {
    showModalBottomSheet<void>(context: context, builder: (_) => _ChoiceSheet(title: 'Payment Method', options: const ['Cash', 'UPI (PhonePe)', 'UPI (Google Pay)', 'UPI (Paytm)', 'Debit Card', 'Credit Card', 'Net Banking', 'Wallet', 'Other'], selected: paymentMethod, onSelected: (value) => setState(() => paymentMethod = value)));
  }

  String _month(int month) => const ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][month - 1];

  Future<void> _save() async {
    if (isSaving) return;
    final amountText = amountController.text.trim().replaceAll(',', '').replaceAll('₹', '');
    final amount = double.tryParse(amountText);
    if (amount == null || !amount.isFinite || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid amount greater than zero.')),
      );
      return;
    }

    setState(() => isSaving = true);
    try {
      final transaction = widget.existing != null
          ? widget.existing!.copyWith(
              title: noteController.text.trim().isEmpty ? category : noteController.text.trim(),
              amount: amount,
              type: isIncome ? TransactionType.income : TransactionType.expense,
              category: category,
              date: selectedDate,
              paymentMethod: paymentMethod,
              note: noteController.text.trim(),
            )
          : await TransactionService.instance.addTransaction(
        title: noteController.text.trim().isEmpty ? category : noteController.text.trim(),
        amount: amount,
        type: isIncome ? TransactionType.income : TransactionType.expense,
        category: category,
        date: selectedDate,
        paymentMethod: paymentMethod,
        note: noteController.text.trim(),
      );
      if (widget.existing != null) {
        final updated = await TransactionService.instance.updateTransaction(transaction);
        if (!mounted) return;
        if (!updated) throw StateError('Transaction no longer exists');
        Navigator.of(context).pop();
        return;
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(
          builder: (_) => TransactionSuccessScreen(
            isIncome: isIncome,
            amount: amount.toStringAsFixed(amount == amount.roundToDouble() ? 0 : 2),
            category: category,
            accent: isIncome ? const Color(0xFF16B981) : const Color(0xFFFF3D6E),
            transactionDate: transaction.date,
          ),
        ),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction could not be saved. Please try again.')),
      );
    } finally {
      if (mounted) setState(() => isSaving = false);
    }
  }
}

class _ChoiceSheet extends StatelessWidget {
  const _ChoiceSheet({required this.title, required this.options, required this.selected, required this.onSelected});
  final String title;
  final List<String> options;
  final String selected;
  final ValueChanged<String> onSelected;
  @override
  Widget build(BuildContext context) => SafeArea(child: ListView(shrinkWrap: true, padding: const EdgeInsets.fromLTRB(18, 18, 18, 24), children: [Text(title, style: const TextStyle(color: Color(0xFF101936), fontSize: 18, fontWeight: FontWeight.w800)), const SizedBox(height: 12), ...options.map((item) => ListTile(title: Text(item), trailing: item == selected ? const Icon(Icons.check_circle_rounded, color: Color(0xFF6C3BFF)) : null, onTap: () { onSelected(item); Navigator.pop(context); }))]));
}

class TransactionSuccessScreen extends StatelessWidget {
  const TransactionSuccessScreen({super.key, required this.isIncome, required this.amount, required this.category, required this.accent, required this.transactionDate});
  final bool isIncome;
  final String amount;
  final String category;
  final Color accent;
  final DateTime transactionDate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FD),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(width: 142, height: 142, decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withAlpha(28)), child: Center(child: Container(width: 88, height: 88, decoration: BoxDecoration(shape: BoxShape.circle, color: accent), child: const Icon(Icons.check_rounded, color: Colors.white, size: 52)))),
                const SizedBox(height: 30),
                const Text('Transaction Added!', style: TextStyle(color: Color(0xFF101936), fontSize: 24, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                Text('Your ${isIncome ? 'income' : 'expense'} of ₹$amount has been added successfully.', textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF747D94), fontSize: 14, height: 1.45)),
                const SizedBox(height: 26),
                Container(width: double.infinity, padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE7EAF3))), child: Row(children: [CircleAvatar(backgroundColor: accent.withAlpha(28), child: Icon(isIncome ? Icons.arrow_upward_rounded : Icons.restaurant_rounded, color: accent)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(category, style: const TextStyle(color: Color(0xFF101936), fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text('${transactionDate.day}/${transactionDate.month}/${transactionDate.year}', style: const TextStyle(color: Color(0xFF747D94), fontSize: 11))])), Text('${isIncome ? '+' : '-'} ₹$amount', style: TextStyle(color: accent, fontWeight: FontWeight.w900))])),
                const SizedBox(height: 28),
                FilledButton(onPressed: () { Navigator.popUntil(context, (route) => route.isFirst); }, style: FilledButton.styleFrom(backgroundColor: const Color(0xFF6C3BFF), minimumSize: const Size.fromHeight(52), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Back to Home', style: TextStyle(fontWeight: FontWeight.w800))),
                const SizedBox(height: 10),
                OutlinedButton(onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute<void>(builder: (_) => AddTransactionForm(isIncome: isIncome))), style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF6C3BFF), minimumSize: const Size.fromHeight(52), side: const BorderSide(color: Color(0xFF6C3BFF)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: const Text('Add Another Transaction', style: TextStyle(fontWeight: FontWeight.w800))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}