import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileService extends ChangeNotifier {
  ProfileService._();
  static final instance = ProfileService._();
  String name = 'Utsav Singh',
      email = 'utsavsingh@example.com',
      phone = '',
      dob = '',
      gender = '',
      about = '';
  Future<void>? _loading;
  Future<void> load() => _loading ??= _read().catchError((Object e) {
    _loading = null;
    throw e;
  });
  Future<void> _read() async {
    final p = await SharedPreferences.getInstance();
    name = p.getString('dhanviq_profile_name') ?? name;
    email = p.getString('dhanviq_profile_email') ?? email;
    phone = p.getString('dhanviq_profile_phone') ?? '';
    dob = p.getString('dhanviq_profile_dob') ?? '';
    gender = p.getString('dhanviq_profile_gender') ?? '';
    about = p.getString('dhanviq_profile_about') ?? '';
    notifyListeners();
  }

  Future<void> save({
    required String newName,
    required String newEmail,
    required String newPhone,
    required String newDob,
    required String newGender,
    required String newAbout,
  }) async {
    final p = await SharedPreferences.getInstance();
    final fields = {
      'name': newName,
      'email': newEmail,
      'phone': newPhone,
      'dob': newDob,
      'gender': newGender,
      'about': newAbout,
    };
    for (final e in fields.entries) {
      if (!await p.setString('dhanviq_profile_${e.key}', e.value)) {
        throw StateError('Unable to save ${e.key}');
      }
    }
    name = newName;
    email = newEmail;
    phone = newPhone;
    dob = newDob;
    gender = newGender;
    about = newAbout;
    notifyListeners();
  }
}
