import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../welcome/welcome_screen.dart';
import 'settings_ui.dart';
import 'profile_service.dart';
import 'profile_screen.dart';
import 'account_settings_screen.dart';
import 'data_backup_screen.dart';
import 'appearance_screen.dart';
import 'currency_region_screen.dart';
import 'notifications_screen.dart';
import 'app_lock_screen.dart';
import 'privacy_policy_screen.dart';
import 'help_support_screen.dart';
import 'about_dhanviq_screen.dart';
export 'profile_screen.dart' show ProfileScreen;

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  static const navy = UI.navy,
      purple = UI.purple,
      page = Color(0xFFF7F8FD),
      muted = Color(0xFF7D879D),
      green = Color(0xFF16B981),
      red = Color(0xFFF0445D);
  @override
  State<SettingsScreen> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    ProfileService.instance.load();
  }

  Widget group(String title, List<Widget> children) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      STitle(title),
      SCard(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
        child: Column(
          children: [
            for (int i = 0; i < children.length; i++) ...[
              if (i > 0)
                Divider(height: 1, indent: 52, color: UI.border(context)),
              children[i],
            ],
          ],
        ),
      ),
    ],
  );
  Widget link(IconData icon, String title, String sub, Widget page) => SRow(
    icon: icon,
    title: title,
    subtitle: sub,
    onTap: () => UI.go(context, page),
  );
  Future<void> logout() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Logout?'),
        content: const Text(
          'Sign out of DHANVIQ on this device? Your saved financial records will remain on this device.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(d, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(d, true),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    final p = await SharedPreferences.getInstance();
    await p.setBool('isLoggedIn', false);
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const WelcomeScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext c) => Scaffold(
    backgroundColor: UI.bg(c),
    body: SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 116),
        children: [
          Text(
            'Settings',
            style: TextStyle(
              color: UI.ink(c),
              fontSize: 26,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Your preferences, your way',
            style: TextStyle(color: UI.sub(c), fontSize: 12),
          ),
          const SizedBox(height: 17),
          AnimatedBuilder(
            animation: ProfileService.instance,
            builder: (c, _) => SCard(
              padding: EdgeInsets.zero,
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => UI.go(c, const ProfileScreen()),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        radius: 26,
                        backgroundColor: Color(0xFFECE6FF),
                        child: Icon(
                          Icons.person_rounded,
                          color: UI.purple,
                          size: 30,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              ProfileService.instance.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: UI.ink(c),
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              ProfileService.instance.email,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: UI.sub(c), fontSize: 11),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.chevron_right_rounded, color: UI.sub(c)),
                    ],
                  ),
                ),
              ),
            ),
          ),
          group('Account', [
            link(
              Icons.manage_accounts_outlined,
              'Account Settings',
              'Profile and account details',
              const AccountDetailsScreen(),
            ),
            link(
              Icons.cloud_outlined,
              'Data & Backup',
              'Export your transactions',
              const DataBackupScreen(),
            ),
          ]),
          group('General', [
            link(
              Icons.dark_mode_outlined,
              'Appearance',
              'Light, Dark and System',
              const AppearanceScreen(),
            ),
            link(
              Icons.currency_rupee_rounded,
              'Currency & Region',
              'Display preferences',
              const CurrencyRegionScreen(),
            ),
          ]),
          group('Notifications', [
            link(
              Icons.notifications_none_rounded,
              'Notifications',
              'Reminder preferences',
              const NotificationsScreen(),
            ),
          ]),
          group('Privacy & Security', [
            link(
              Icons.lock_outline_rounded,
              'App Lock',
              'Security information',
              const AppLockScreen(),
            ),
            link(
              Icons.description_outlined,
              'Privacy Policy',
              'How local data is handled',
              const PrivacyPolicyScreen(),
            ),
          ]),
          group('Support & About', [
            link(
              Icons.help_outline_rounded,
              'Help & Support',
              'FAQs and feedback',
              const HelpSupportScreen(),
            ),
            link(
              Icons.info_outline_rounded,
              'About DHANVIQ',
              'App details',
              const AboutDhanviqScreen(),
            ),
          ]),
          const SizedBox(height: 20),
          SCard(
            padding: EdgeInsets.zero,
            child: SRow(
              icon: Icons.logout_rounded,
              title: 'Logout',
              subtitle: 'Sign out of this device',
              onTap: logout,
            ),
          ),
        ],
      ),
    ),
  );
}
