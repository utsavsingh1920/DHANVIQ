import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../settings/settings_screen.dart';
import '../goals/goals_screen.dart';
import '../models/transaction_model.dart';
import '../services/transaction_service.dart';
import '../services/finance_plan_service.dart';
import '../navigation/main_navigation_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    this.onNavigationTap,
    this.showNavigation = true,
  });

  final ValueChanged<int>? onNavigationTap;
  final bool showNavigation;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const _navy = Color(0xFF101936);
  static const _purple = Color(0xFF6C3BFF);
  static const _mint = Color(0xFF16CFA5);
  static const _pink = Color(0xFFFF4D82);
  static const _muted = Color(0xFF747D94);
  static const _background = Color(0xFFF7F8FD);

  bool _showBalance = true;
  bool get _firstTime => _service.transactions.isEmpty &&
      _plans.goals.isEmpty && _plans.bills.isEmpty && !_hasBudget;

  bool get _hasBudget {
    final now = DateTime.now();
    return _budgetCategories.any((c) => _plans.budgetFor(now.year, now.month, c) > 0);
  }

  static const _budgetCategories = <String>[
    'Food', 'Shopping', 'Transport', 'Bills', 'Entertainment',
    'Health', 'Education', 'Other',
  ];
  final _service = TransactionService.instance;
  final _plans = FinancePlanService.instance;
  @override
  void initState() {
    super.initState();
    _service.addListener(_refresh);
    _plans.addListener(_refresh);
    _initializeHomeData();
  }

  Future<void> _initializeHomeData() async {
    try {
      await Future.wait([_service.initialize(), _plans.initialize()]);
      if (mounted) setState(() {});
    } catch (error) {
      debugPrint('Could not initialize Home data: $error');
    }
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _service.removeListener(_refresh);
    _plans.removeListener(_refresh);
    super.dispose();
  }

  String _money(double value) {
    final parts = value
        .abs()
        .toStringAsFixed(value.abs() % 1 == 0 ? 0 : 2)
        .split('.');
    final whole = parts.first;
    if (whole.length <= 3) return '${value < 0 ? '-' : ''}${parts.join('.')}';
    final last = whole.substring(whole.length - 3);
    var head = whole.substring(0, whole.length - 3);
    final groups = <String>[];
    while (head.length > 2) {
      groups.insert(0, head.substring(head.length - 2));
      head = head.substring(0, head.length - 2);
    }
    if (head.isNotEmpty) groups.insert(0, head);
    return '${value < 0 ? '-' : ''}${groups.join(',')},$last${parts.length > 1 ? '.${parts[1]}' : ''}';
  }

  void _add(bool income) => Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => AddTransactionForm(isIncome: income),
    ),
  );
  // Goals is a separate screen, not a bottom navigation tab.
  void _openGoals() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const GoalsScreen()),
    );
  }

  void _openNotifications() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const _HomeNotificationsScreen()),
    );
  }

  void _navigate(int index, String label) {
    if (label == 'Goals') {
      _openGoals();
      return;
    }
    if (widget.onNavigationTap != null) {
      widget.onNavigationTap!(index);
    } else if (index != 0) {
      // When Home is opened standalone, use the app's main navigation.
      Navigator.of(context).push(
        MaterialPageRoute<void>(builder: (_) => const MainNavigationScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
        systemNavigationBarDividerColor: Colors.white,
      ),
      child: Scaffold(
        backgroundColor: _background,
        extendBody: true,
        body: Stack(
          children: [
            const Positioned.fill(child: _HomeBackground()),
            SafeArea(
              bottom: false,
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverPersistentHeader(
                    pinned: true,
                    delegate: _HomeStickyHeader(child: _header()),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 112),
                    sliver: SliverList.list(
                      children: [
                        _balanceCard(),
                        const SizedBox(height: 20),
                        _quickActions(),
                        const SizedBox(height: 18),
                        _tipCard(),
                        const SizedBox(height: 22),
                        _sectionTitle(
                          'Recent Transactions',
                          action: 'See All',
                          onTap: () => _navigate(1, 'Transactions'),
                        ),
                        const SizedBox(height: 8),
                        _transactionsCard(),
                        const SizedBox(height: 22),
                        _sectionTitle(
                          'Monthly Overview',
                          action: 'See Details',
                          onTap: () => _navigate(3, 'Insights'),
                        ),
                        const SizedBox(height: 10),
                        _monthlyOverview(),
                        const SizedBox(height: 24),
                        _sectionTitle(
                          'Budget Progress',
                          action: 'See All',
                          onTap: _setBudget,
                        ),
                        const SizedBox(height: 10),
                        _budgetProgress(),
                        const SizedBox(height: 24),
                        _sectionTitle(
                          'Savings Goals',
                          action: 'See All',
                          onTap: () => _openGoals(),
                        ),
                        const SizedBox(height: 10),
                        _savingsGoals(),
                        const SizedBox(height: 24),
                        _sectionTitle(
                          'Income vs Expense',
                          trailing: _periodChip(),
                        ),
                        const SizedBox(height: 10),
                        _incomeExpenseChart(),
                        const SizedBox(height: 24),
                        _sectionTitle(
                          'Upcoming Expenses',
                          action: 'See All',
                          onTap: _addBill,
                        ),
                        const SizedBox(height: 10),
                        _upcomingExpenses(),
                        const SizedBox(height: 14),
                        _smartInsight(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: widget.showNavigation
            ? Container(
                width: 62,
                height: 62,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF8652FF), Color(0xFF5B25E8)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x556C3BFF),
                      blurRadius: 20,
                      offset: Offset(0, 8),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => _navigate(2, 'Add Transaction'),
                    customBorder: const CircleBorder(),
                    child: const Icon(
                      Icons.add_rounded,
                      color: Colors.white,
                      size: 34,
                    ),
                  ),
                ),
              )
            : null,
        bottomNavigationBar: widget.showNavigation
            ? _BottomNavigation(onTap: _navigate)
            : null,
      ),
    );
  }

  Widget _header() {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(color: Color(0x176C3BFF), blurRadius: 12),
            ],
          ),
          child: Image.asset(
            'assets/icon/dhanviq_icon.png',
            fit: BoxFit.contain,
            filterQuality: FilterQuality.high,
          ),
        ),
        const SizedBox(width: 11),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'DHANVIQ',
                style: TextStyle(
                  color: _navy,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'Track • Save • Grow',
                style: TextStyle(color: _muted, fontSize: 12.5),
              ),
            ],
          ),
        ),
        _roundAction(
          icon: Icons.notifications_none_rounded,
          showDot: false,
          onTap: _openNotifications,
        ),
        const SizedBox(width: 9),

        // PROFILE BUTTON
        GestureDetector(
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ProfileScreen()),
            );
          },
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFE8E1FF),
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: const Icon(Icons.person_rounded, color: _purple, size: 27),
          ),
        ),
      ],
    );
  }

  Widget _roundAction({
    required IconData icon,
    required VoidCallback onTap,
    bool showDot = false,
  }) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Material(
          color: Colors.white.withValues(alpha: .88),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(14),
            child: SizedBox(
              width: 42,
              height: 42,
              child: Icon(icon, color: _navy, size: 24),
            ),
          ),
        ),
        if (showDot)
          const Positioned(
            top: 5,
            right: 5,
            child: CircleAvatar(radius: 4, backgroundColor: _pink),
          ),
      ],
    );
  }

  Widget _balanceCard() {
    return Container(
      height: 166,
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF082B51), Color(0xFF13206B), Color(0xFF6B31E9)],
          stops: [0, .6, 1],
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x30132B72),
            blurRadius: 24,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: 0,
            bottom: 0,
            child: _firstTime
                ? const _GrowingPlant()
                : const SizedBox(width: 145, height: 92,
                    child: CustomPaint(painter: _BalanceGraphPainter())),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text(
                    'Total Balance',
                    style: TextStyle(color: Color(0xFFDDE8FF), fontSize: 14),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {
                      setState(() {
                        _showBalance = !_showBalance;
                      });
                    },
                    child: Icon(
                      _showBalance
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 7),
              Text(
                _showBalance
                    ? '₹${_money(_service.totalBalance - _plans.goals.fold<double>(0, (sum, goal) => sum + goal.saved))}'
                    : '₹••••••',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -.7,
                ),
              ),
              const Spacer(),
              Text(
                'Income ₹${_money(_service.incomeForMonth(DateTime.now().year, DateTime.now().month))}  •  Expense ₹${_money(_service.expensesForMonth(DateTime.now().year, DateTime.now().month))}',
                style: const TextStyle(color: Color(0xFFDDE8FF), fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _quickActions() {
    const actions = [
      (Icons.add_rounded, 'Add\nIncome', Color(0xFFE0FAF2), _mint),
      (Icons.remove_rounded, 'Add\nExpense', Color(0xFFFFE6EF), _pink),
      (Icons.pie_chart_rounded, 'Set\nBudget', Color(0xFFEDE7FF), _purple),
      (
        Icons.track_changes_rounded,
        'Add\nGoal',
        Color(0xFFFFF1D8),
        Color(0xFFFFA91E),
      ),
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: actions.map((item) {
        return Expanded(
          child: InkWell(
            onTap: () {
              if (item.$2 == 'Add\nIncome') {
                _add(true);
              } else if (item.$2 == 'Add\nExpense') {
                _add(false);
              } else if (item.$2 == 'Add\nGoal') {
                _openGoals();
              } else {
                _setBudget();
              }
            },
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Column(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      color: item.$3,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(item.$1, color: item.$4, size: 28),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    item.$2,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _navy,
                      fontSize: 12,
                      height: 1.18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _tipCard() {
    return _SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      color: const Color(0xFFF1F5FF),
      child: Row(
        children: [
          Container(
            width: 43,
            height: 43,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF0C9),
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Icon(
              Icons.lightbulb_rounded,
              color: Color(0xFFFFB621),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _firstTime ? 'Welcome to DHANVIQ!' : 'You’re on track!',
                  style: TextStyle(
                    color: _navy,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  _service.transactions.isEmpty
                      ? 'Start by adding your first transaction to build your financial journey.'
                      : 'This month you spent ₹${_money(_service.expensesForMonth(DateTime.now().year, DateTime.now().month))}. Check your monthly overview for details.',
                  style: TextStyle(color: _muted, fontSize: 12, height: 1.35),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: _muted),
        ],
      ),
    );
  }

  Widget _sectionTitle(
    String title, {
    String? action,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: _navy,
              fontSize: 17,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        if (trailing is Widget) trailing,
        if (action != null)
          TextButton(
            onPressed: onTap,
            style: TextButton.styleFrom(
              minimumSize: Size.zero,
              padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 3),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: Text(
              action,
              style: const TextStyle(
                color: _purple,
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                decoration: TextDecoration.underline,
              ),
            ),
          ),
      ],
    );
  }

  // Icons stay in this Home file; no additional widget files required.
  IconData _categoryIcon(String category, TransactionType type) {
    switch (category.trim().toLowerCase()) {
      case 'food':
      case 'groceries':
      case 'restaurant':
        return Icons.restaurant_rounded;
      case 'shopping':
        return Icons.shopping_bag_rounded;
      case 'transport':
      case 'travel':
        return Icons.directions_car_rounded;
      case 'bills':
      case 'utilities':
        return Icons.receipt_long_rounded;
      case 'entertainment':
        return Icons.movie_rounded;
      case 'health':
      case 'medical':
        return Icons.medical_services_rounded;
      case 'salary':
        return Icons.work_rounded;
      case 'freelance':
        return Icons.laptop_mac_rounded;
      case 'bonus':
        return Icons.card_giftcard_rounded;
      case 'education':
        return Icons.school_rounded;
      case 'rent':
        return Icons.home_rounded;
      case 'other':
        return type == TransactionType.income
            ? Icons.savings_rounded
            : Icons.category_rounded;
      default:
        return type == TransactionType.income
            ? Icons.arrow_downward_rounded
            : Icons.arrow_upward_rounded;
    }
  }

  Widget _emptyCard({
    required IconData icon,
    required String title,
    required String description,
    required String button,
    required VoidCallback onTap,
    bool tall = false,
  }) {
    if (tall) {
      return _SoftCard(
        padding: const EdgeInsets.fromLTRB(18, 22, 18, 15),
        child: Column(
          children: [
            Container(
              width: 78,
              height: 78,
              decoration: const BoxDecoration(
                color: Color(0xFFF2EFFF), shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 43, color: _purple),
            ),
            const SizedBox(height: 13),
            Text(title, textAlign: TextAlign.center,
              style: const TextStyle(color: _navy, fontSize: 15,
                fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(description, textAlign: TextAlign.center,
              style: const TextStyle(color: _muted, fontSize: 12.5, height: 1.4)),
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, height: 45,
              child: FilledButton.icon(
                onPressed: onTap,
                style: FilledButton.styleFrom(
                  backgroundColor: _purple,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                icon: const Icon(Icons.add_rounded, size: 23),
                label: FittedBox(fit: BoxFit.scaleDown,
                  child: Text(button, style: const TextStyle(fontWeight: FontWeight.w700))),
              ),
            ),
          ],
        ),
      );
    }
    return _SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 18),
      child: Row(
        children: [
          Container(
            width: 74, height: 74,
            decoration: const BoxDecoration(
              color: Color(0xFFF2EFFF), shape: BoxShape.circle),
            child: Icon(icon, size: 37, color: _purple),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: _navy, fontSize: 13.5,
                fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(description, style: const TextStyle(
                color: _muted, fontSize: 11.8, height: 1.35)),
              const SizedBox(height: 11),
              SizedBox(width: double.infinity, height: 35,
                child: FilledButton(
                  onPressed: onTap,
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFFF1ECFF),
                    foregroundColor: _purple, elevation: 0,
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: Text(button, style: const TextStyle(
                    fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _transactionsCard() {
    final items = _service.transactions.take(4).toList();
    if (items.isEmpty) {
      return _emptyCard(
        icon: Icons.find_in_page_outlined,
        title: 'No transactions yet',
        description: 'Add your first income or expense\nto get started.',
        button: 'Add Your First Transaction',
        onTap: () => _add(true),
        tall: true,
      );
    }
    return _SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 5),
      child: Column(
        children: [
          for (final item in items) ...[
            InkWell(
              onTap: () => _navigate(1, 'Transactions'),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: item.type == TransactionType.income
                          ? const Color(0xFFDDF9F0)
                          : const Color(0xFFFFE5ED),
                      child: Icon(
                        _categoryIcon(item.category, item.type),
                        color: item.type == TransactionType.income
                            ? _mint
                            : _pink,
                      ),
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            style: const TextStyle(
                              color: _navy,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${item.date.day}/${item.date.month}/${item.date.year} • ${item.category}',
                            style: const TextStyle(color: _muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '${item.type == TransactionType.income ? '+' : '-'} ₹${_money(item.amount)}',
                      style: TextStyle(
                        color: item.type == TransactionType.income
                            ? _mint
                            : _pink,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (item != items.last)
              const Divider(height: 1, color: Color(0xFFECEEF5)),
          ],
        ],
      ),
    );
  }

  Widget _monthlyOverview() {
    final now = DateTime.now();
    final expenses = _service
        .transactionsForMonth(now.year, now.month)
        .where((t) => t.type == TransactionType.expense)
        .toList();
    final total = expenses.fold<double>(0, (sum, t) => sum + t.amount);
    final byCategory = <String, double>{};
    for (final t in expenses) {
      byCategory.update(
        t.category,
        (v) => v + t.amount,
        ifAbsent: () => t.amount,
      );
    }
    final sorted = byCategory.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    const colors = [
      _pink,
      _purple,
      Color(0xFFFFBB32),
      Color(0xFF2D83ED),
      _mint,
    ];
    if (total <= 0) {
      return _SoftCard(
        child: Row(children: [
          const _PlaceholderBars(),
          const SizedBox(width: 16),
          const Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('No data yet', style: TextStyle(color: _navy, fontWeight: FontWeight.w800)),
              SizedBox(height: 5),
              Text('Add transactions to see your spending breakdown.',
                style: TextStyle(color: _muted, fontSize: 12)),
            ],
          )),
        ]),
      );
    }
    return _SoftCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          SizedBox(
            width: 142,
            height: 142,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomPaint(
                  size: const Size.square(142),
                  painter: _DonutPainter(
                    values: sorted.map((e) => e.value).toList(),
                    colors: List.generate(
                      sorted.length,
                      (i) => colors[i % colors.length],
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FittedBox(
                      child: Text(
                        '₹${_money(total)}',
                        style: const TextStyle(
                          color: _navy,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const Text(
                      'Spent',
                      style: TextStyle(color: _muted, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 17),
          Expanded(
            child: sorted.isEmpty
                ? const Text(
                    'No expenses this month',
                    style: TextStyle(color: _muted, fontSize: 11),
                  )
                : Column(
                    children: [
                      for (var i = 0; i < sorted.length && i < 5; i++)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 4.5,
                                backgroundColor: colors[i % colors.length],
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  sorted[i].key,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: _muted,
                                    fontSize: 11,
                                  ),
                                ),
                              ),
                              Text(
                                '${(sorted[i].value / total * 100).round()}%',
                                style: const TextStyle(
                                  color: _navy,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _budgetProgress() {
    final now = DateTime.now();
    final categories = [
      'Food',
      'Shopping',
      'Transport',
      'Bills',
      'Entertainment',
      'Health',
      'Education',
      'Other',
    ];
    final configured = categories
        .where((c) => _plans.budgetFor(now.year, now.month, c) > 0)
        .toList();
    if (configured.isEmpty) {
      return _emptyCard(icon: Icons.donut_large_rounded, title: 'No budget set yet', description: 'Set a monthly budget to track your spending and stay on top of your goals.', button: 'Set Budget', onTap: _setBudget);
    }
    final spent = <String, double>{};
    for (final t in _service.transactionsForMonth(now.year, now.month)) {
      if (t.type == TransactionType.expense) {
        spent[t.category] = (spent[t.category] ?? 0) + t.amount;
      }
    }
    return _SoftCard(
      child: Column(
        children: configured.map((c) {
          final limit = _plans.budgetFor(now.year, now.month, c);
          final used = spent[c] ?? 0.0;
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        c,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          color: _navy,
                        ),
                      ),
                    ),
                    Text(
                      '₹${_money(used)} / ₹${_money(limit)}',
                      style: const TextStyle(fontSize: 11, color: _muted),
                    ),
                  ],
                ),
                const SizedBox(height: 7),
                LinearProgressIndicator(
                  value: (used / limit).clamp(0.0, 1.0),
                  minHeight: 7,
                  color: used > limit ? _pink : _purple,
                  backgroundColor: const Color(0xFFECEFF8),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _savingsGoals() {
    final goals = _plans.goals;
    if (goals.isEmpty) {
      return _emptyCard(icon: Icons.flag_rounded, title: 'No goals yet', description: 'Create your first savings goal to turn your dreams into reality.', button: 'Add Goal', onTap: () => _openGoals());
    }
    return _SoftCard(
      child: Column(
        children: goals
            .take(3)
            .map(
              (g) => Padding(
                key: ValueKey(g.id),
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.track_changes_rounded,
                          size: 20,
                          color: _purple,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            g.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                              color: _navy,
                            ),
                          ),
                        ),
                        Text(
                          '${(g.progress * 100).round()}%',
                          style: const TextStyle(
                            color: _purple,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '₹${_money(g.saved)} / ₹${_money(g.target)}',
                      style: const TextStyle(fontSize: 11, color: _muted),
                    ),
                    const SizedBox(height: 7),
                    LinearProgressIndicator(
                      value: g.progress,
                      minHeight: 7,
                      color: _mint,
                      backgroundColor: const Color(0xFFECEFF8),
                    ),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Future<void> _setBudget() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _BudgetSheet(),
    );
  }

  Future<void> _addBill() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => const _BillSheet(),
    );
  }

  Widget _periodChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE4E6EF)),
      ),
      child: const Row(
        children: [
          Text(
            'This Month',
            style: TextStyle(
              color: _navy,
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(width: 4),
          Icon(Icons.keyboard_arrow_down_rounded, color: _muted, size: 17),
        ],
      ),
    );
  }

  Widget _incomeExpenseChart() {
    final now = DateTime.now();
    final weeksIncome = List<double>.filled(4, 0);
    final weeksExpense = List<double>.filled(4, 0);
    for (final t in _service.transactionsForMonth(now.year, now.month)) {
      final index = ((t.date.day - 1) ~/ 8).clamp(0, 3);
      if (t.type == TransactionType.income) {
        weeksIncome[index] += t.amount;
      } else {
        weeksExpense[index] += t.amount;
      }
    }
    if (weeksIncome.every((v) => v == 0) && weeksExpense.every((v) => v == 0)) {
      return _SoftCard(
        child: Column(children: [
          const SizedBox(height: 8),
          const _PlaceholderBars(wide: true),
          const SizedBox(height: 12),
          Text('Add transactions to see your income vs expense trend.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: _muted, fontSize: 12)),
        ]),
      );
    }
    return _SoftCard(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 11),
      child: Column(
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CircleAvatar(radius: 4, backgroundColor: _mint),
              SizedBox(width: 5),
              Text('Income', style: TextStyle(color: _muted, fontSize: 10)),
              SizedBox(width: 13),
              CircleAvatar(radius: 4, backgroundColor: _pink),
              SizedBox(width: 5),
              Text('Expense', style: TextStyle(color: _muted, fontSize: 10)),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 150,
            child: CustomPaint(
              painter: _BarChartPainter(
                income: weeksIncome,
                expense: weeksExpense,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _upcomingExpenses() {
    final bills = _plans.bills.where((b) => !b.paid).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    if (bills.isEmpty) {
      return _emptyCard(icon: Icons.calendar_month_rounded, title: 'No upcoming expenses', description: 'Your upcoming bills, subscriptions and reminders will appear here.', button: 'Add Reminder', onTap: _addBill);
    }
    return _SoftCard(
      child: Column(
        children: bills
            .take(4)
            .map(
              (b) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.event_note_rounded, color: _purple),
                title: Text(
                  b.title,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  '${b.dueDate.day}/${b.dueDate.month}/${b.dueDate.year}',
                ),
                trailing: PopupMenuButton<String>(
                  tooltip: 'Expense options',
                  onSelected: (action) {
                    if (action == 'paid') {
                      _plans.markPaid(b.id);
                    } else {
                      _plans.deleteBill(b.id);
                    }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(
                      value: 'paid',
                      child: Text('₹${_money(b.amount)} · Mark paid'),
                    ),
                    const PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _smartInsight() {
    final now = DateTime.now();
    final income = _service.incomeForMonth(now.year, now.month);
    final expense = _service.expensesForMonth(now.year, now.month);
    return _SoftCard(
      color: const Color(0xFFECE5FF),
      child: Row(
        children: [
          const Icon(Icons.lightbulb_outline_rounded, color: _purple),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Smart Insight',
                  style: TextStyle(color: _purple, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  income == 0 && expense == 0
                      ? 'Start your journey. Add your income or first expense to get personalized insights and smart tips.'
                      : 'This month: income ₹${_money(income)}, expenses ₹${_money(expense)} and net ₹${_money(income - expense)}.',
                  style: const TextStyle(color: _muted, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// The sheet owns its controllers. They are disposed only after the sheet's
// TextFields have been removed from the widget tree.
class _BudgetSheet extends StatefulWidget {
  const _BudgetSheet();

  @override
  State<_BudgetSheet> createState() => _BudgetSheetState();
}

class _BudgetSheetState extends State<_BudgetSheet> {
  final _amount = TextEditingController();
  String _category = 'Food';
  bool _saving = false;
  static const _categories = [
    'Food', 'Shopping', 'Transport', 'Bills', 'Entertainment',
    'Health', 'Education', 'Other',
  ];

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_saving) return;
    final value = double.tryParse(_amount.text.trim());
    if (value == null || !value.isFinite || value <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid amount')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final now = DateTime.now();
      await FinancePlanService.instance.setBudget(
        now.year, now.month, _category, value,
      );
      if (mounted) Navigator.of(context).pop();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save budget: $error')),
        );
        setState(() => _saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.viewInsetsOf(context).bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Set Monthly Budget',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              DropdownButton<String>(
                value: _category,
                isExpanded: true,
                items: _categories
                    .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: _saving ? null : (value) {
                  if (value != null) setState(() => _category = value);
                },
              ),
              TextField(
                controller: _amount,
                enabled: !_saving,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Budget amount (₹)'),
              ),
              const SizedBox(height: 15),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(_saving ? 'Saving...' : 'Save Budget'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _BillSheet extends StatefulWidget {
  const _BillSheet();

  @override
  State<_BillSheet> createState() => _BillSheetState();
}

class _BillSheetState extends State<_BillSheet> {
  final _title = TextEditingController();
  final _amount = TextEditingController();
  DateTime _due = DateTime.now().add(const Duration(days: 1));
  bool _saving = false;

  @override
  void dispose() {
    _title.dispose();
    _amount.dispose();
    super.dispose();
  }

  Future<void> _chooseDate() async {
    final today = DateTime.now();
    final first = DateTime(today.year, today.month, today.day);
    final selected = await showDatePicker(
      context: context,
      firstDate: first,
      lastDate: DateTime(2040),
      initialDate: _due.isBefore(first) ? first : _due,
    );
    if (mounted && selected != null) setState(() => _due = selected);
  }

  Future<void> _save() async {
    if (_saving) return;
    final value = double.tryParse(_amount.text.trim());
    if (_title.text.trim().isEmpty ||
        value == null || !value.isFinite || value <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter valid expense details')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      await FinancePlanService.instance.addBill(_title.text.trim(), value, _due);
      if (mounted) Navigator.of(context).pop();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save expense: $error')),
        );
        setState(() => _saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          20, 20, 20, MediaQuery.viewInsetsOf(context).bottom + 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Schedule Expense',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              TextField(
                controller: _title,
                enabled: !_saving,
                decoration: const InputDecoration(labelText: 'Expense title'),
              ),
              TextField(
                controller: _amount,
                enabled: !_saving,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Amount (₹)'),
              ),
              TextButton(
                onPressed: _saving ? null : _chooseDate,
                child: Text('Due date: ${_due.day}/${_due.month}/${_due.year}'),
              ),
              FilledButton(
                onPressed: _saving ? null : _save,
                child: Text(_saving ? 'Saving...' : 'Save Expense'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftCard extends StatelessWidget {
  const _SoftCard({
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.color = Colors.white,
  });

  final Widget child;
  final EdgeInsets padding;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: color.withValues(alpha: .94),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withValues(alpha: .88)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x126C3BFF),
            blurRadius: 18,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _BottomNavigation extends StatelessWidget {
  const _BottomNavigation({required this.onTap});

  final void Function(int index, String label) onTap;

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.home_rounded, 'Home'),
      (Icons.swap_horiz_rounded, 'Transactions'),
      (Icons.add_rounded, ''),
      (Icons.bar_chart_rounded, 'Insights'),
      (Icons.settings_rounded, 'Settings'),
    ];

    return Container(
      height: 78 + MediaQuery.paddingOf(context).bottom,
      padding: EdgeInsets.only(bottom: MediaQuery.paddingOf(context).bottom),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Color(0x1F101936),
            blurRadius: 22,
            offset: Offset(0, -5),
          ),
        ],
      ),
      child: Row(
        children: List.generate(items.length, (index) {
          if (index == 2) {
            return const Expanded(child: SizedBox());
          }

          final selected = index == 0;

          return Expanded(
            child: InkWell(
              onTap: () => onTap(index, items[index].$2),
              child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      items[index].$1,
                      color: selected
                          ? _HomeScreenState._purple
                          : _HomeScreenState._muted,
                      size: 24,
                    ),
                    const SizedBox(height: 3),
                    Text(
                      items[index].$2,
                      style: TextStyle(
                        color: selected
                            ? _HomeScreenState._purple
                            : _HomeScreenState._muted,
                        fontSize: 9.5,
                        fontWeight: selected
                            ? FontWeight.w700
                            : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _HomeBackground extends StatelessWidget {
  const _HomeBackground();

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFBFBFF), Color(0xFFF7F9FF), Color(0xFFF4FAFC)],
            ),
          ),
        ),
        Positioned(
          top: -145,
          left: -125,
          child: _blob(310, const Color(0xFF7950F2), .10),
        ),
        Positioned(
          top: 150,
          right: -190,
          child: _blob(410, const Color(0xFF22D3B6), .07),
        ),
        Positioned(
          bottom: 120,
          left: -180,
          child: _blob(390, const Color(0xFF5A8DFF), .06),
        ),
      ],
    );
  }

  static Widget _blob(double size, Color color, double opacity) {
    return Transform.rotate(
      angle: math.pi / 8,
      child: Container(
        width: size,
        height: size * .68,
        decoration: BoxDecoration(
          color: color.withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(size * .35),
        ),
      ),
    );
  }
}

class _BalanceGraphPainter extends CustomPainter {
  const _BalanceGraphPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [Color(0x44713DFF), Color(0xFF36D7D0)],
      ).createShader(Offset.zero & size);

    final heights = [28.0, 47.0, 62.0, 49.0, 78.0];

    for (var i = 0; i < heights.length; i++) {
      final rect = Rect.fromLTWH(
        i * 25.0 + 10,
        size.height - heights[i],
        13,
        heights[i],
      );

      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(7)),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class _DonutPainter extends CustomPainter {
  const _DonutPainter({required this.values, required this.colors});
  final List<double> values;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    final total = values.fold<double>(0, (sum, v) => sum + v);
    if (total <= 0) {
      canvas.drawArc(
        (Offset.zero & size).deflate(15),
        0,
        math.pi * 2,
        false,
        Paint()
          ..color = const Color(0xFFECEEF6)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 19,
      );
      return;
    }
    final rect = Offset.zero & size;

    var start = -math.pi / 2;

    for (var i = 0; i < values.length; i++) {
      final sweep = math.pi * 2 * values[i] / total;

      final paint = Paint()
        ..color = colors[i % colors.length]
        ..style = PaintingStyle.stroke
        ..strokeWidth = 19
        ..strokeCap = StrokeCap.butt;

      canvas.drawArc(rect.deflate(15), start, sweep - .025, false, paint);

      start += sweep;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class _BarChartPainter extends CustomPainter {
  const _BarChartPainter({required this.income, required this.expense});
  final List<double> income;
  final List<double> expense;

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = const Color(0xFFE8EAF2)
      ..strokeWidth = 1;

    final maxAmount = [
      ...income,
      ...expense,
    ].fold<double>(0, (max, v) => v > max ? v : max);
    final labels = List.generate(
      4,
      (i) => (maxAmount * (3 - i) / 3).toStringAsFixed(0),
    );

    final textPainter = TextPainter(textDirection: TextDirection.ltr);

    for (var i = 0; i < 4; i++) {
      final y = 8 + i * ((size.height - 35) / 3);

      canvas.drawLine(Offset(34, y), Offset(size.width, y), gridPaint);

      textPainter.text = TextSpan(
        text: labels[i],
        style: const TextStyle(color: Color(0xFF8C94A8), fontSize: 8),
      );

      textPainter.layout();

      textPainter.paint(canvas, Offset(0, y - 5));
    }

    final maxValue = [
      ...income,
      ...expense,
    ].fold<double>(0, (max, v) => v > max ? v : max);
    final scale = maxValue <= 0 ? 1.0 : maxValue;
    final chartHeight = size.height - 38;
    final groupWidth = (size.width - 42) / 4;

    for (var i = 0; i < 4; i++) {
      final x = 43 + i * groupWidth;

      _bar(
        canvas,
        Rect.fromLTWH(
          x,
          8 + chartHeight * (1 - income[i] / scale),
          14,
          chartHeight * income[i] / scale,
        ),
        _HomeScreenState._mint,
      );

      _bar(
        canvas,
        Rect.fromLTWH(
          x + 18,
          8 + chartHeight * (1 - expense[i] / scale),
          14,
          chartHeight * expense[i] / scale,
        ),
        _HomeScreenState._pink,
      );

      textPainter.text = TextSpan(
        text: 'Week ${i + 1}',
        style: const TextStyle(color: Color(0xFF8C94A8), fontSize: 8),
      );

      textPainter.layout();

      textPainter.paint(canvas, Offset(x - 4, size.height - 17));
    }
  }

  void _bar(Canvas canvas, Rect rect, Color color) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(3)),
      Paint()..color = color.withValues(alpha: .88),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

class _HomeStickyHeader extends SliverPersistentHeaderDelegate {
  _HomeStickyHeader({required this.child});
  final Widget child;
  @override
  double get minExtent => 76;
  @override
  double get maxExtent => 76;
  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return Container(
      color: const Color(0xFFF7F8FD),
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
      alignment: Alignment.center,
      child: child,
    );
  }

  @override
  bool shouldRebuild(covariant _HomeStickyHeader oldDelegate) => true;
}

class _PlaceholderBars extends StatelessWidget {
  const _PlaceholderBars({this.wide = false});
  final bool wide;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: wide ? double.infinity : 112,
      height: wide ? 95 : 88,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(wide ? 8 : 4, (i) => Container(
          width: wide ? 15 : 19,
          height: (wide ? 32.0 : 25.0) + (i % 4) * 14,
          decoration: const BoxDecoration(
            color: Color(0xFFE9E5FF),
            borderRadius: BorderRadius.vertical(top: Radius.circular(4))),
        )),
      ),
    );
  }
}

class _GrowingPlant extends StatelessWidget {
  const _GrowingPlant();
  @override
  Widget build(BuildContext context) {
    return SizedBox(width: 110, height: 100,
      child: Stack(alignment: Alignment.bottomCenter, children: [
        Positioned(bottom: 15, child: Container(width: 7, height: 50,
          decoration: BoxDecoration(color: const Color(0xFF62D9AA),
            borderRadius: BorderRadius.circular(5)))),
        Positioned(bottom: 42, left: 24, child: Transform.rotate(angle: -.65,
          child: Container(width: 35, height: 19,
            decoration: const BoxDecoration(color: Color(0xFF55DDA6),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(35),
                bottomRight: Radius.circular(35)))))),
        Positioned(bottom: 48, right: 22, child: Transform.rotate(angle: .65,
          child: Container(width: 35, height: 19,
            decoration: const BoxDecoration(color: Color(0xFF77EDBC),
              borderRadius: BorderRadius.only(topRight: Radius.circular(35),
                bottomLeft: Radius.circular(35)))))),
        Positioned(bottom: 0, child: Container(width: 43, height: 32,
          decoration: const BoxDecoration(color: Color(0xFFC6A2FF),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(12),
              top: Radius.circular(4))))),
      ]),
    );
  }
}

// Local notification inbox. Notification preferences remain in Settings.
// No sample notifications are shown as if they were real user activity.
class _HomeNotificationsScreen extends StatelessWidget {
  const _HomeNotificationsScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FD),
      appBar: AppBar(
        title: const Text('Notifications',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
        centerTitle: true,
        backgroundColor: const Color(0xFFF7F8FD),
        foregroundColor: const Color(0xFF101936),
        elevation: 0,
      ),
      body: const SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircleAvatar(
                  radius: 42,
                  backgroundColor: Color(0xFFEDE7FF),
                  child: Icon(Icons.notifications_none_rounded,
                      color: Color(0xFF6C3BFF), size: 42),
                ),
                SizedBox(height: 18),
                Text('No notifications yet',
                    style: TextStyle(fontSize: 18,
                        fontWeight: FontWeight.w800, color: Color(0xFF101936))),
                SizedBox(height: 8),
                Text('Your app updates and reminders will appear here when available.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13, height: 1.4,
                        color: Color(0xFF747D94))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
